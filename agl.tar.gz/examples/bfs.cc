#include <algorithm>
#include <iostream>
#include <iomanip>
#include <vector>

#include <shmem.h>
extern "C" {
  #include <libgetput.h>
}
#include <selector.h>
#include <agl.h>

#include "util.h"

using agl::NodeID;

struct BFSEdgeMsg {
  NodeID src; 
  NodeID dest; 
};

std::vector<NodeID> PickSources(const agl::CSRGraph &g, int numSources){
  // Generating sources
  std::vector<NodeID> sources;
  std::mt19937 rng;
  rng.seed(agl::kRandSeed);
  std::uniform_int_distribution<int> pes(0, shmem_n_pes() - 1);
  std::uniform_int_distribution<NodeID> localVertices(0, g.get_local_num_nodes() - 1);

  for(int i = 0; i < numSources; i++){
    int pickerPE = 0;
    int localPicker = 0;

    NodeID localSource = 0;
    NodeID globalSource = 0;
    NodeID source = 0;

    if(shmem_my_pe() == 0){
        //Pick random PE
        localPicker = pes(rng);
    }
    pickerPE = lgp_reduce_add_d(localPicker);

    if(shmem_my_pe() == pickerPE){
      while(1){
        localSource = localVertices(rng);
        if(g.degree(localSource) != 0 && std::find(sources.begin(), sources.end(), g.map_to_global(localSource)) == sources.end()){
          break;
        }
      }
      globalSource = g.map_to_global(localSource);
    }
    source = lgp_reduce_add_l(globalSource);
    sources.push_back(source);
  }
  return sources;
}


class TDBFSSelector: public hclib::Selector<1, BFSEdgeMsg> { 
public: 
  TDBFSSelector(const agl::CSRGraph &_g, std::vector<NodeID> &_parents, std::vector<NodeID> &_nextFrontier, std::vector<bool> &_visited) : g_(_g), parents_(_parents), nextFrontier_(_nextFrontier), visited_(_visited) {
	  mb[0].process = [this](BFSEdgeMsg m, int sender_rank) { this->VisitedChild(m, sender_rank); };
  } 

protected:
  void VisitedChild(BFSEdgeMsg m, int sender_rank) {
    //If unvisited, mark as visited and add to next frontier
    NodeID v_local = g_.map_to_local(m.dest);
    if(!visited_[v_local]){
      visited_[v_local] = true;
      nextFrontier_.push_back(m.dest);
      parents_[v_local] = m.src;
    }
  }

  const agl::CSRGraph &g_;
  std::vector<NodeID> &parents_;
  std::vector<NodeID> &nextFrontier_;
  std::vector<bool> &visited_;
  
};

void RunBFS(const agl::CSRGraph &g, NodeID source, std::vector<NodeID> &parents){
  int level = 0;
  //int64_t messages = 0;
  int nodesInLevel = 1;
  NodeID mask = shmem_n_pes() - 1;
  std::vector<NodeID> frontier, nextFrontier;
  std::vector<bool> visited(g.get_local_num_nodes(), false);
  
  //Initialize frontier with root
  if(shmem_my_pe() == g.map_to_host(source)){
    visited[g.map_to_local(source)] = true;
    frontier.push_back(source);
    parents[g.map_to_local(source)] = source;
  }

  while(nodesInLevel){
    //auto level_start = agl::start_timer();
    TDBFSSelector tdbfs(g, parents, nextFrontier, visited);
    //hclib::finish([&tdbfs, &g, &parents, &nextFrontier, &visited, &frontier]() {  
    hclib::finish([&]() {  
      tdbfs.start();
      for(NodeID u_global: frontier){ 
        NodeID u_local =  g.map_to_local(u_global);
        for(NodeID v_global: g.neigh_global(u_local)){
          //messages++;
          tdbfs.send(0, {u_global, v_global}, g.map_to_host(v_global));
        } 
      }
      tdbfs.done(0);
    });
    lgp_barrier();
    //std::cout << "Level " << level << std::endl;
    //level++;
    //tdbfs.print_statistics(0); 
    
    //double level_time = agl::stop_timer(level_start);
    //agl::R0Printf("Time for level %d: %fs\n", level, level_time);
    //messages = lgp_reduce_add_l(messages);
    //agl::R0Printf("Level: %d\n", level);
    //agl::R0Printf("Messages in level: %u\n", messages);
    //messages = 0;
    //level++;

    nodesInLevel = lgp_reduce_add_l(nextFrontier.size());
    frontier.swap(nextFrontier);
    nextFrontier.clear(); 
  }
  lgp_barrier();
  //agl::R0Printf("Messages: %u\n", messages);
  
}

//Single-threaded
bool BFSVerifier(const agl::CSRGraph &g, NodeID source, const std::vector<NodeID> &parent){
  std::vector<int> depth(g.get_local_num_nodes(), -1);
  NodeID u_global, u_local;
  depth[source] = 0;
  std::vector<NodeID> to_visit;
  to_visit.reserve(g.get_local_num_nodes());
  to_visit.push_back(source);
  for (auto it = to_visit.begin(); it != to_visit.end(); it++) {
    u_local = *it;
    u_global = g.map_to_global(u_local);
    for (NodeID v_global : g.neigh_global(u_local)) {
      if (depth[v_global] == -1) {
        depth[v_global] = depth[u_global] + 1;
        to_visit.push_back(v_global);
      }
    }
  }
  for (NodeID u_local: g.local_vertices()) {
    u_global = g.map_to_global(u_local);
    if ((depth[u_global] != -1) && (parent[u_global] != -1)) {
      if (u_global == source) {
        if (!((parent[u_global] == u_global) && (depth[u_global] == 0))) {
          std::cout << "Source wrong" << std::endl;
          return false;
        }
        continue;
      }
      bool parent_found = false;
      for (NodeID v_global : g.neigh_global(u_local)) {
        if (v_global == parent[u_global]) {
          if (depth[v_global] != depth[u_global] - 1) {
            std::cout << "Wrong depths for " << u_global << " & " << v_global << std::endl;
            return false;
          }
          parent_found = true;
          break;
        }
      }
      if (!parent_found) {
        std::cout << "Couldn't find edge from " << parent[u_global] << " to " << u_global << std::endl;
        return false;
      }
    } else if (depth[u_global] != parent[u_global]) {
      std::cout << "Reachability mismatch" << std::endl;
      return false;
    }
  }
  return true;
}



int main(int argc, char** argv) {
   CLI cli(argc, argv, "Top-Down BFS");
  if (!cli.ParseArgs())
    return -1;

  const char *deps[] = { "system" };


  hclib::launch(deps, 1, [&cli] {
    // Generate graph using RmatGenerator & build with Auto mapper
    const agl::CSRGraph g = agl::GraphAndBuild(cli);

    std::cout << "Number of edges: " << g.global_num_edges << std::endl;
    //std::cout << "Number of edges: " << g.get_local_num_edges() << std::endl;
    double totalTime = 0;
    double totalTeps = 0;
    
    /*
    for(int i = 0; i < shmem_n_pes(); i++){
      if(shmem_my_pe() == i){
        std::cout << g.get_local_num_edges() << " edges on PE " << i << std::endl;
      }
    }
    */
    auto time_start = agl::start_timer();
    std::vector<NodeID> sources = PickSources(g, 1);
    double sp_time = agl::stop_timer(time_start);
    agl::R0Printf("Time to generate %d source(s): %f\n", 1, sp_time);

    for(int i = 0; i < 1; i++){
      std::vector<NodeID> parents(g.get_local_num_nodes(), -1);
      time_start = agl::start_timer();
      //RunBFS(g, sources[i], parents);
      double tdbfs_time = agl::stop_timer(time_start);
      double tdbfs_teps = g.global_num_edges / tdbfs_time;  
      
      totalTime += tdbfs_time;
      totalTeps += tdbfs_teps;

      agl::R0Printf("Running BFS %d: Source %u\n", i, sources[i]);
      agl::R0Printf("Time for BFS %d is %f\n", i, tdbfs_time);
      agl::R0Printf("TEPS for BFS %d is %.5e\n", i, tdbfs_teps);

      /*
      //Verifying Result
      agl::R0Printf("Validating BFS %d: Source %u\n", i, sources[i]);
      auto validate_start = agl::start_timer();
      if(!BFSVerifier(g, sources[i], parents)){
        agl::R0Printf("Failed validation for BFS %d\n", i);
        break;
      }
      double validate_time = agl::stop_timer(validate_start);
      agl::R0Printf("Validate time for BFS %d is %f\n", i, validate_time);
      */
    }

    double avgTime = totalTime / 1;   
    double avgTeps = totalTeps / 1;      

    agl::R0Printf("Mean Time: %f\n", avgTime);
    agl::R0Printf("Mean TEPS: %.5e\n", avgTeps);
  });

  return 0;
}