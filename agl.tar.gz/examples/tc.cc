#include <algorithm>
#include <vector>

#include <agl.h>

using agl::NodeID;

struct TCMsg {
  NodeID v_to_search;
  NodeID search_target;
};


static inline uint64_t _rdtsc(void) {
    unsigned a, d;
    asm volatile("rdtsc" : "=a" (a), "=d" (d) : : "%rbx", "%rcx");
    return ((uint64_t) a) | (((uint64_t) d) << 32);
}

struct TCSelector: public hclib::Selector<1, TCMsg> {
  explicit TCSelector(const agl::CSRGraph &g) : g_(g), local_triangles(0) {
    mb[0].process = [this](TCMsg m, int sender_rank) {
      if (g_.is_neigh_of_global(m.v_to_search, m.search_target))
        local_triangles++;
    };
  }

  // using constraint w < v < u
  void sendAll() {
    for (NodeID u_local : g_.local_vertices()) {
      NodeID u = g_.map_to_global(u_local);
      for (NodeID v : g_.neigh_global(u_local)) {
        if (v > u)
          break;
        for (NodeID w : g_.neigh_global(u_local)) {
          if (w > v)
            break;
          send(0, {v, w}, g_.map_to_host(v));
        }
      }
    }
  }

  int64_t local_triangles;

 protected:
  const agl::CSRGraph &g_;
};


// single-threaded
int64_t TCAlternative(const agl::CSRGraph &g) {
  assert(shmem_n_pes() == 1);
  int64_t total = 0;
  std::vector<NodeID> intersection;
  intersection.reserve(g.get_local_num_nodes());
  for (NodeID u_local : g.local_vertices()) {
    for (NodeID v : g.neigh_global(u_local)) {
      NodeID v_local = g.map_to_local(v);
      auto new_end = std::set_intersection(g.neigh_global(u_local).begin(),
                                           g.neigh_global(u_local).end(),
                                           g.neigh_global(v_local).begin(),
                                           g.neigh_global(v_local).end(),
                                           intersection.begin());
      intersection.resize(new_end - intersection.begin());
      total += intersection.size();
    }
  }
  total = total / 6;  // each triangle was counted 6 times
  return total;
}


void TCVerifier(const agl::CSRGraph &g, const int64_t triangles) {
  int64_t ver_triangles = TCAlternative(g);
  agl::R0Printf("%ld ver_triangles\n", ver_triangles);
  if (triangles == ver_triangles) {
    agl::R0Printf("PASS - total matches verifier\n");
  } else {
    agl::R0Printf("FAIL - total does not matches verifier\n");
  }
}


int64_t TriangleCount(const agl::CSRGraph &g) {
  TCSelector tcs(g);
  uint64_t start = _rdtsc();
  hclib::finish([&tcs] {
    tcs.start();
    tcs.sendAll();
    tcs.done(0);
  });
  fprintf(stderr, "Total-time reported by application: %ld\n", _rdtsc() - start);
  int64_t triangles = lgp_reduce_add_l(tcs.local_triangles);
  return triangles;
}


int main(int argc, char** argv) {
  CLIApp cli(argc, argv, "Graph, Build and Count Triangles");
  if (!cli.ParseArgs())
    return -1;

  const char *deps[] = { "system" };

  hclib::launch(deps, 1, [&cli] {
    const agl::CSRGraph g = agl::GraphAndBuild(cli);

    for (int trial=0; trial<1; trial++) {
      auto time_start = agl::start_timer();
      int64_t triangles = TriangleCount(g);
      double tc_time = agl::stop_timer(time_start);
      agl::R0Printf("%ld triangles\n", triangles);
      // if (cli.do_verify())
      //   TCVerifier(g, triangles);
      agl::R0PrintTime("tc_time", tc_time);
    }
  });

  return 0;
}
