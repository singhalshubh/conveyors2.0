#include <iostream>

#include <agl.h>

using agl::NodeID;

int main(int argc, char** argv) {
  CLI cli(argc, argv, "Graph, Build and Print Topology");
  if (!cli.ParseArgs())
    return -1;

  const char *deps[] = { "system" };

  hclib::launch(deps, 1, [&cli] {
    const agl::CSRGraph g = agl::GraphAndBuild(cli);

    // Print topology of rank 0
    if (shmem_my_pe() == 0) {
      std::cout << "Topology on rank 0:" << std::endl;
      for (NodeID local : g.local_vertices()) {
        NodeID u = g.map_to_global(local);
        std::cout << u << ":";
        for (NodeID v : g.neigh_global(local)) {
          std::cout << " " << v;
        }
        std::cout << std::endl;
      }
    }
  });

  return 0;
}
