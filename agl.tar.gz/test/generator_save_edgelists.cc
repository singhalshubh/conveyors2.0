#include <iostream>
#include <fstream>

#include <agl.h>
#include <string>
#include <libgetput.h>
#include <selector.h>

using agl::NodeID;
using namespace agl;

int main(int argc, char** argv) {
  CLI cli(argc, argv, "Generate and save the edge list for each PE");
  if (!cli.ParseArgs())
    return -1;

  const char *deps[] = { "system" };

  hclib::launch(deps, 1, [&cli] {
    if (cli.filename() == "") {
      R0Printf("usage: -f <save path> (\".\" for cwd)\n");
      exit(-1);
    }

    Generator rgenerator(cli.scale(), cli.degree(), cli.gen_type());
    EdgeChunk gen_result = rgenerator.GenerateEL();
    
    // Save edge list to file (for each pe)
    std::stringstream ss;
    ss << cli.filename();
    ss << "/pe";
    if (shmem_my_pe() < 10)
      ss << "0";
    ss << shmem_my_pe();
    ss << ".el";
    std::ofstream tout;
    tout.open(ss.str());
    if (!tout.is_open()) {
      R0Printf("Failed to open file\n");
      exit(-1);
    }
    for (Edge e : gen_result.el) {
      tout << e.first << " " << e.second << std::endl;
    }
    tout.close();
  });

  return 0;
}
