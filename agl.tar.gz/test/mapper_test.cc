#include <iostream>
#include <vector>

#include <agl.h>


using agl::NodeID;

bool test_global_local(NodeID num_elems, std::vector<agl::Mapper*> maps) {
  bool pass = true;
  NodeID v;
  for (v=0; v<num_elems; v++) {
    NodeID host = maps[0]->to_host(v);
    assert(host < maps.size());
    NodeID v_local = maps[host]->to_local(v);
    NodeID v_global_computed = maps[host]->to_global(v_local);
    if (v != v_global_computed) {
      pass = false;
      printf("   %ld -> %ld != %ld at host %ld\n", v_local, v_global_computed, v, host);
      break;
    }
  }
  if (pass)
    printf("%-14s: PASS\n", maps[0]->name());
  else
    printf("%-14s: FAIL at %ld\n", maps[0]->name(), v);
  return pass;
}

bool test_all(NodeID num_elems, NodeID num_pes) {
  bool all_pass = true;
  std::vector<agl::Mapper*> CyclicMV;
  for (NodeID pe=0; pe<num_pes; pe++)
    CyclicMV.push_back(new agl::CyclicMapper(pe, num_pes));
  all_pass &= test_global_local(num_elems, CyclicMV);

  std::vector<agl::Mapper*> RangeMV;
  for (NodeID pe=0; pe<num_pes; pe++)
    RangeMV.push_back(new agl::RangeMapper(num_elems, pe, num_pes));
  all_pass &= test_global_local(num_elems, RangeMV);

  if (agl::is_pow2(num_pes)) {
    std::vector<agl::Mapper*> XORMV;
    for (NodeID pe=0; pe<num_pes; pe++)
      XORMV.push_back(new agl::XORMapper(num_elems, pe, num_pes));
    all_pass &= test_global_local(num_elems, XORMV);
  }

  std::vector<agl::Mapper*> SnakeMV;
  for (NodeID pe=0; pe<num_pes; pe++)
    SnakeMV.push_back(new agl::SnakeMapper(pe, num_pes));
  all_pass &= test_global_local(num_elems, SnakeMV);

  std::vector<agl::Mapper*> RotationMV;
  for (NodeID pe=0; pe<num_pes; pe++)
    RotationMV.push_back(new agl::RotationMapper(pe, num_pes));
  all_pass &= test_global_local(num_elems, RotationMV);

  std::vector<agl::Mapper*> SnakeRotationMV;
  for (NodeID pe=0; pe<num_pes; pe++)
    SnakeRotationMV.push_back(new agl::SnakeRotationMapper(pe, num_pes));
  all_pass &= test_global_local(num_elems, SnakeRotationMV);
  return all_pass;
}

int main() {
  NodeID num_elems = 1l << 20;
  NodeID num_pes = 16;
  bool all_pass = true;

  std::cout << "Power of 2 Elements, Power of 2 PEs (" << num_pes << ")" << std::endl;
  all_pass &= test_all(num_elems, num_pes);

  num_pes = 17;
  std::cout << std::endl << "Power of 2 Elements, Non-power of 2 PEs (" << num_pes << ")" << std::endl;
  all_pass &= test_all(num_elems, num_pes);

  num_elems = (1l << 20) + 7;
  num_pes = 16;
  std::cout << std::endl << "Non-power of 2 Elements, Power of 2 PEs (" << num_pes << ")" << std::endl;
  all_pass &= test_all(num_elems, num_pes);

  num_pes = 17;
  std::cout << std::endl << "Non-power of 2 Elements, Non-power of 2 PEs (" << num_pes << ")" << std::endl;
  all_pass &= test_all(num_elems, num_pes);

  return !all_pass;
}
