#include <iostream>
#include <vector>

#include <agl.h>


using agl::NodeID;

void print_maps(NodeID num_elems, NodeID num_pes, std::vector<agl::Mapper*> maps) {
  printf("       ");
  for (agl::Mapper *map : maps) {
    printf("%14s", map->name());
  }
  printf("\n");
  for (NodeID v=0; v<65; v++) {
    printf(" %5ld:", v);
    for (agl::Mapper *map : maps) {
      printf("%14ld", map->to_host(v));
    }
    printf("\n");
  }
}


int main() {
  NodeID num_elems = 1l << 7;
  NodeID num_pes = 16;

  std::vector<agl::Mapper*> maps = {
    // new agl::SnakeRotationMapper(0, num_pes),
    new agl::CyclicMapper(0, num_pes),
    new agl::XORMapper(num_elems, 0, num_pes),
  };

  print_maps(num_elems, num_pes, maps);

  return 0;
}
