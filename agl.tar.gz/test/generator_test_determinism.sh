#!/bin/bash

# test cases
gen=('-u' '-g' '-u' '-g' '-u' '-g' '-u' '-g')
scl=('01' '01' '10' '10' '10' '10' '20' '20')
deg=('01' '01' '01' '01' '20' '20' '04' '04')

# num pes to compare
test_npes=('01' '04' '11' '23')

set -e
make generator_save_edgelists 1>/dev/null
temp_dir="test_gen_temp"
mkdir $temp_dir 
for npe in ${test_npes[@]}; do
  mkdir "$temp_dir/pes_$npe"
done

printf "Testing deterministic generation between number of PEs:"
for npe in ${test_npes[@]}; do
  printf "($npe)"
done
printf "\n"

fail_ct=0
for i in ${!gen[@]}; do
  printf "Test %d: %s %s -k %s\n" $((1+$i)) ${gen[$i]} ${scl[$i]} ${deg[$i]}

  printf "  Generating:"
  for npe in ${test_npes[@]}; do
    path="$temp_dir/pes_$npe"
    printf "($npe)"
    oshrun -n $npe "./generator_save_edgelists" ${gen[$i]} ${scl[$i]} -k ${deg[$i]} -f $path 1>/dev/null 2>/dev/null
  done

  printf "  Sorting:"
  for npe in ${test_npes[@]}; do
    path="$temp_dir/pes_$npe"
    printf "($npe)"
    sort -o "$temp_dir/el_$npe" "$path/"*
  done

  printf "  Comparing:"
  failed=0
  for (( i=0; i<=((${#test_npes[@]}-2)); i++)) do
    file1="$temp_dir/el_${test_npes[$i]}"
    file2="$temp_dir/el_${test_npes[(($i+1))]}"
    if diff $file1 $file2 >/dev/null; then
      printf "*"
    else
      printf "(${file1}!=${file2})"
      failed=1
      fail_ct+=1
    fi
  done
  printf "\n"
  if [ $failed -eq 1 ]; then
    printf "  --Failed--\n\n"
  else
    printf "  --Passed--\n\n"
  fi
done

printf "Passed %s/%s tests\n" $((${#gen[@]}-$fail_ct)) ${#gen[@]}
printf "Cleaning up\n"
rm -r $temp_dir
