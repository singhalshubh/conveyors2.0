#include <iostream>

#include <shmem.h>
extern "C" {
  #include <libgetput.h>
}
#include <selector.h>
#include <agl.h>

typedef int seq_t;


struct PingPongActor: public hclib::Selector<2, seq_t> {
  seq_t curr_seq;
  seq_t burst_cnt;
  const seq_t send_limit;
  const seq_t burst_limit;

  static int other_pe(int pe) {
    return (pe + 1) & 1;
  }

  void receive(seq_t m_seq, int sender_rank) {
    burst_cnt++;
    if ((burst_cnt == burst_limit) && (curr_seq < send_limit)) {
      for (burst_cnt=0; burst_cnt < burst_limit; burst_cnt++)
        send(sender_rank, curr_seq++, sender_rank);
      burst_cnt = 0;
      if (curr_seq == send_limit) {
        this->done(0);
      }
    }
  }

  PingPongActor(seq_t send_limit, seq_t burst_limit) : send_limit(send_limit),
      burst_limit(burst_limit), curr_seq(0), burst_cnt(0) {
    mb[0].process = [this](seq_t m_seq, int sender_rank) {
      this->receive(m_seq, sender_rank);
    };
    mb[1].process = [this](seq_t m_seq, int sender_rank) {
      this->receive(m_seq, sender_rank);
    };
  }

  void kickoff() {
    if (shmem_my_pe() == 0) {
      for (burst_cnt=0; burst_cnt < burst_limit; burst_cnt++)
        send(1, curr_seq++, 1);
      burst_cnt = 0;
      if (curr_seq == send_limit) {
        this->done(0);
      }
    }
  }
};


int main(int argc, char** argv) {
  const char *deps[] = { "system" };
  const char *usage = "Usage: %s rounds burst_length\n";

  int total_msgs = 1000;
  int burst_length = 1;
  if (argc >= 2) total_msgs = atoi(argv[1]);
  if (argc >= 3) burst_length = atoi(argv[2]);
  if (argc >= 4 || total_msgs == 0 || burst_length == 0) {
    agl::R0Printf(usage, argv[0]);
    exit(-1);
  }
  assert((total_msgs % burst_length) == 0);
  int rounds = total_msgs / burst_length;

  hclib::launch(deps, 1, [=] {
    assert(shmem_n_pes() == 2);
    auto time_start = agl::start_timer();
    PingPongActor ppa_ptr(total_msgs, burst_length);
    hclib::finish([&ppa_ptr] {
      ppa_ptr.start();
      ppa_ptr.kickoff();
    });
    double total_time = agl::stop_timer(time_start);
    double us_per_rt = total_time / rounds * 1e6;
    double msgs_per_ms = total_msgs / total_time / 1e3;
    agl::R0Printf("%d msgs in bursts of %d\n", total_msgs, burst_length);
    agl::R0Printf("Raw Time:                %5.5lf s\n", total_time);
    agl::R0Printf("Round Trip Message Rate: %5.5lf KRT/s\n", msgs_per_ms);
    agl::R0Printf("Time per Round Trip:     %5.5lf us\n", us_per_rt);
  });

  return 0;
}
