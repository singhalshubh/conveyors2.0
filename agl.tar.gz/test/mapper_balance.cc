#include <iostream>
#include <vector>

#include <agl.h>


using agl::NodeID;


void analyze_balance(int num_pes, const agl::CSRGraph &g, agl::Mapper *map) {
  std::vector<int64_t> degree_totals(num_pes, 0);
  for (NodeID v_local=0; v_local<g.get_local_num_nodes(); v_local++) {
    degree_totals[map->to_host(v_local)] += g.degree(v_local);
  }
  std::cout << "Simulated Balance (for edges)" << std::endl;
  agl::CalcAndPrintBalance(degree_totals);
}


int main(int argc, char** argv) {
  const char *deps[] = { "system" };

  int scale = 10;
  int degree = 16;
  NodeID num_pes = 16;

  if (argc >= 2) scale = atoi(argv[1]);
  if (argc >= 3) num_pes = atoi(argv[2]);
  if (argc >= 4 || scale == 0 || num_pes == 0) {
    agl::R0Printf("fix args\n");
    exit(-1);
  }

  hclib::launch(deps, 1, [=] {
    assert(shmem_n_pes() == 1);

    // Generate graph using RmatGenerator & build with SnakeRotation mapper
    const agl::CSRGraph g = agl::GenerateAndBuild(scale, degree,
                                                  agl::GeneratorType::RMAT,
                                                  agl::MapperType::SnakeRot);

    // agl::Mapper *map = new agl::CyclicMapper(0, num_pes);
    agl::Mapper *map = new agl::XORMapper(g.global_num_nodes, 0, num_pes);
    // agl::Mapper *map = new agl::SnakeRotationMapper(0, num_pes);
    // agl::Mapper *map = new agl::RangeMapper(g.global_num_nodes, 0, num_pes);
    analyze_balance(num_pes, g, map);
  });

  return 0;
}
