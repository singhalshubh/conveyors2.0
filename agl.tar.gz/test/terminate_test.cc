#include <vector>

#include <agl.h>
#include <terminate.h>

using agl::NodeID;

const int MBLevel1 = 0;
const int MBLevel2 = 1;

// Messaging Plan
//  * Each PE #X will send X messages to each other PE (including self)
//  * Between each pair of PEs, messages are sent 1 at a time
//    - 1st message sent to MBLevel1
//    - response sent back to MBLevel2
//    - if more messages to send, send next one to MBLevel1

struct TwoLevelTester: public hclib::Selector<2, int> {
  TwoLevelTester() : my_pe_(shmem_my_pe()), num_pes_(shmem_n_pes()),
                     seq_counts_(num_pes_, 0), rt_(num_pes_) {
    mb[MBLevel1].process = [this](int m_seq, int sender_pe) {
      send(MBLevel2, m_seq, sender_pe);
    };
    mb[MBLevel2].process = [this](int m_seq, int sender_pe) {
      seq_counts_[sender_pe] = m_seq;
      if (m_seq < my_pe_)
        send(MBLevel1, m_seq+1, sender_pe);
      else
        rt_.DecRemaining();
    };
  }

  void MainBody() {
    // start sends
    for (int dest_pe=0; dest_pe<num_pes_; dest_pe++) {
      send(MBLevel1, 0, dest_pe);
    }
    // wait for all to complete
    // rt_.PollAndYieldForAll();
    rt_.LocalPollAndYield();
  }

  bool CheckCompleteness() {
    bool local_pass = true;
    for (int pe=0; pe<num_pes_; pe++) {
      if (seq_counts_[pe] != my_pe_) {
        printf("seq%d, idx%d, pe%d\n", seq_counts_[pe], pe, my_pe_);
        local_pass = false;
        break;
      }
    }
    int64_t pes_pass = lgp_reduce_add_l(local_pass ? 1 : 0);
    return pes_pass == num_pes_;
  }

  int my_pe_;
  int num_pes_;
  std::vector<int> seq_counts_;
  agl::RemainingTerminator rt_;
};


int main(int argc, char** argv) {
  const char *deps[] = { "system" };

  hclib::launch(deps, 1, [] {
    auto time_start = agl::start_timer();
    TwoLevelTester tl;
    hclib::finish([&tl] {
      tl.start();
      tl.MainBody();
      // for (int i=0; i<100; i++)
      //   hclib::yield_at(nic);
      tl.done(0);
    });
    double terminate_time = agl::stop_timer(time_start);
    agl::R0PrintTime("terminate_time", terminate_time);
    bool pass_verify = tl.CheckCompleteness();
    agl::R0Printf("Verification: %s\n", pass_verify ? "PASS" : "FAIL");
  });

  return 0;
}
