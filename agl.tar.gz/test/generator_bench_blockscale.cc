#include <iostream>

#include <agl.h>
#include <libgetput.h>
#include <selector.h>

using agl::NodeID;
using namespace agl;

int main(int argc, char** argv) {
  CLI cli(argc, argv, "Test Generator speed by sweeping block_scale");
  if (!cli.ParseArgs())
    return -1;
  
  const char *deps[] = { "system" };

  hclib::launch(deps, 1, [&cli] {
    int granularity = 12;
    int scale = (cli.scale() == -1 ? 20 : cli.scale());
    int default_block_scale = scale / 2; // defined by generator.h

    // sweep block_scale
    for (int i = 0; i <= granularity; i++) {
      int block_scale = scale * i / granularity;

      R0Printf("block_scale: %d %s\n", block_scale,
        block_scale == default_block_scale ? "(default)" : "");

      Generator rgenerator(scale, cli.degree(), cli.gen_type(), block_scale);
      rgenerator.GenerateEL();
      R0Printf("\n");
    }
  });

  return 0;
}
