#include <algorithm>
#include <iostream>
#include <vector>

#include <agl.h>
#include <permute.h>

using agl::NodeID;


struct VerifyActor: public hclib::Selector<1, NodeID> {
  bool double_recv_found = false;
  NodeID pings_nums_recv = 0;
  std::vector<bool> local_touched;

  VerifyActor(std::shared_ptr<agl::Mapper> map, NodeID num_local) :
      local_touched(num_local, false) {
    mb[0].process = [this, &map](NodeID m_global_v, int sender_pe) {
      pings_nums_recv++;
      NodeID local_v = map->to_local(m_global_v);
      if (local_touched[local_v]) {
        double_recv_found = true;
      }
      local_touched[local_v] = true;
    };
  }
};

bool VerifyPerm(std::shared_ptr<agl::Mapper> map, std::vector<NodeID> &perm) {
  VerifyActor va(map, perm.size());
  hclib::finish([&va, &map, &perm] {
    va.start();
    for (NodeID v : perm) {
      va.send(0, v, map->to_host(v));
    }
    va.done(0);
  });
  bool local_ok = !va.double_recv_found && va.pings_nums_recv == perm.size();
  NodeID global_ok_total = lgp_reduce_add_l(local_ok ? 1 : 0);
  return global_ok_total == shmem_n_pes();
}


int main(int argc, char** argv) {
  CLI cli(argc, argv, "test: build graph & randomly permute vertex IDs");
  if (!cli.ParseArgs())
    return -1;

  const char *deps[] = { "system" };

  hclib::launch(deps, 1, [&cli] {
    const agl::CSRGraph g = agl::GraphAndBuild(cli);

    // Permute the global IDs
    auto time_start = agl::start_timer();
    std::vector<NodeID> perm = agl::GenRandRelabel(g);
    double relabel_time = agl::stop_timer(time_start);
    agl::R0PrintTime("relabel_time", relabel_time);

    // Verify no IDs duplicated or lost
    time_start = agl::start_timer();
    bool pass_verify = VerifyPerm(g.get_map(), perm);
    double verify_time = agl::stop_timer(time_start);
    agl::R0PrintTime("verify_time", verify_time);
    agl::R0Printf("Verification: %s\n", pass_verify ? "PASS" : "FAIL");
  });

  return 0;
}