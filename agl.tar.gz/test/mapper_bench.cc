#include <iostream>
#include <vector>

#include <agl.h>


using agl::NodeID;

std::vector<NodeID> bench_map_range_local(NodeID num_elems, const agl::Mapper *map) {
  std::vector<NodeID> v(num_elems, 0);
  auto time_start = agl::start_timer();
  for (NodeID n=0; n<num_elems; n++) {
    v[n] = map->to_local(n);
    // v[n] = map->to_host(n);
  }
  double secs = agl::stop_timer(time_start);
  double rate = num_elems / secs;
  printf("%-14s %3.5lf s (%3.3lf MT/s)\n", map->name(), secs, rate / 1e6);
  return v;
}

void bench_all(NodeID num_elems, NodeID pe, NodeID num_pes = 1024) {
  bench_map_range_local(num_elems, new agl::IdentityMapper(pe, num_pes));
  bench_map_range_local(num_elems, new agl::CyclicMapper(pe, num_pes));
  if (agl::is_pow2(num_pes))
    bench_map_range_local(num_elems, new agl::XORMapper(num_elems, pe, num_pes));
  bench_map_range_local(num_elems, new agl::RangeMapper(num_elems, pe, num_pes));
  bench_map_range_local(num_elems, new agl::SnakeMapper(pe, num_pes));
  bench_map_range_local(num_elems, new agl::RotationMapper(pe, num_pes));
  bench_map_range_local(num_elems, new agl::SnakeRotationMapper(pe, num_pes));
}

int main() {
  NodeID num_elems = 1l << 24;
  NodeID pe = 7;
  NodeID num_pes = 1024;
  std::cout << "Power of 2 PEs (" << num_pes << ")" << std::endl;
  bench_all(num_elems, pe, num_pes);
  num_pes = 1025;
  std::cout << std::endl << "Non-power of 2 PEs (" << num_pes << ")" << std::endl;
  bench_all(num_elems, pe, num_pes);
  return 0;
}
