#ifndef PERFORMANCE_MEASURE_H_
#define PERFORMANCE_MEASURE_H_

#include "./generator/generator.h"
#include "./builder/builder.h"

#include <vector>
#include <string>

void compare_builders_against_rmat_util(int edgefactor, int SCALE){

    if (shmem_my_pe() == 0) { /* Not an official part of the results */
        fprintf(stderr, "edgefactor=%d, SCALE=%d\n", edgefactor, SCALE);
    }

    //RMATGraph(tg, nglobalverts, SCALE, seed1, seed2);
    Generator* rgenerator = new Generator(edgefactor, SCALE, RmatGenerator);
    ResultFromGenerator rgeneratorResult = rgenerator->GenerateEL();
    if (shmem_my_pe() == 0) { /* Not an official part of the results */
        fprintf(stderr, "graph_generation: %f s\n", rgeneratorResult.make_graph_time);
    }

    std::vector<GraphBuilderTypeEnum> builders = {Cyclic , Range, SnakeHash, RotationHash, SnakeRotation};
    BuilderBase* builder;
    ResultFromBuilder builderResult;

    for(GraphBuilderTypeEnum builder_type: builders){
        /* Make user's graph data structure. */
        builder = new BuilderBase(rgeneratorResult, builder_type);
        builderResult = builder->buildCSRGraph();
        if (shmem_my_pe() == 0) { /* Not an official part of the results */
            fprintf(stderr, "construction_time: %f s\n", builderResult.build_graph_time);
        }
        if (shmem_my_pe() == 0) { /* Not an official part of the results */
            builderResult.printShufflingEfficiencyStats();
        }
    }

}

void compare_builders_against_rmat(){

    fprintf(stderr,"compare_builders_against_rmat\n");
    for(int i=3; i<25; i++){
        fprintf(stderr,"\n\n\n");
        compare_builders_against_rmat_util(16, i);
    }

}


void compare_generators_util(int edgefactor, int SCALE){

    if (shmem_my_pe() == 0) { /* Not an official part of the results */
        fprintf(stderr, "edgefactor=%d, SCALE=%d\n", edgefactor, SCALE);
    }
    
    std::vector<GraphGeneratorTypeEnum> generators = {UniformGenerator, RmatGenerator};
    Generator* generator;
    ResultFromGenerator generatorResult;

    for(GraphGeneratorTypeEnum generator_type: generators){
        //RMATGraph(tg, nglobalverts, SCALE, seed1, seed2);
        generator = new Generator(edgefactor, SCALE, generator_type);
        generatorResult = generator->GenerateEL();
        if (shmem_my_pe() == 0) { /* Not an official part of the results */
            fprintf(stderr, "graph_generation: %f s\n", generatorResult.make_graph_time);
        }
    }

}

void compare_generators(){

    fprintf(stderr,"compare_generators\n");
    for(int i=3; i<25; i++){
        fprintf(stderr,"\n\n\n");
        compare_generators_util(16, i);
    }

}




#endif  // PERFORMANCE_MEASURE_H_