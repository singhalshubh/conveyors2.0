/* Copyright (C) 2010 The Trustees of Indiana University.                  */
/*                                                                         */
/* Use, modification and distribution is subject to the Boost Software     */
/* License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at */
/* http://www.boost.org/LICENSE_1_0.txt)                                   */
/*                                                                         */
/*  Authors: Jeremiah Willcock                                             */
/*           Andrew Lumsdaine                                              */
/*           Anton Korzh                                                   */


/* These need to be before any possible inclusions of stdint.h or inttypes.h.
 * */
#ifndef __STDC_LIMIT_MACROS
#define __STDC_LIMIT_MACROS
#endif
#ifndef __STDC_FORMAT_MACROS
#define __STDC_FORMAT_MACROS
#endif
#include <math.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <limits.h>
#include <stdint.h>
#include <inttypes.h>

#include "../../src/bale3/bfs/src/csr_reference.h"
#include "../../src/bale3/bfs/src/aml.h"
#include "../../src/bale3/bfs/src/common.h"

#include "./generator/generator.h"
#include "./builder/builder.h"

#include "selector.h"
#include "libgetput.h"

extern "C" {
	
}

tuple_graph rmatGenerator_non_agl(int edgefactor, int SCALE) {

	tuple_graph tg;
	tg.data_in_file = false;

	tg.nglobaledges = (int64_t)(edgefactor) << SCALE;
	
	float* weightmemory;
	tg.weightmemory = weightmemory;
	
	int64_t global_vertices = (int64_t)(1) << SCALE;

	uint64_t seed1 = 2, seed2 = 3;

	uint_fast32_t seed[5];
	make_mrg_seed(seed1, seed2, seed);

	MPI_Offset nchunks_in_file = (tg.nglobaledges + FILE_CHUNKSIZE - 1) / FILE_CHUNKSIZE;
	int64_t bitmap_size_in_bytes = int64_min(BITMAPSIZE, (global_vertices + CHAR_BIT - 1) / CHAR_BIT);
	if (bitmap_size_in_bytes * size * CHAR_BIT < global_vertices) {
		bitmap_size_in_bytes = (global_vertices + size * CHAR_BIT - 1) / (size * CHAR_BIT);
	}
	int ranks_per_row = ((global_vertices + CHAR_BIT - 1) / CHAR_BIT + bitmap_size_in_bytes - 1) / bitmap_size_in_bytes;
	int nrows = size / ranks_per_row;
	int my_row = -1, my_col = -1;

	MPI_Comm cart_comm;
	{
		int dims[2] = {size / ranks_per_row, ranks_per_row};
		int periods[2] = {0, 0};
		MPI_Cart_create(MPI_COMM_WORLD, 2, dims, periods, 1, &cart_comm);
	}
	int in_generating_rectangle = 0;
	if (cart_comm != MPI_COMM_NULL) {
		in_generating_rectangle = 1;
		{
			int dims[2], periods[2], coords[2];
			MPI_Cart_get(cart_comm, 2, dims, periods, coords);
			my_row = coords[0];
			my_col = coords[1];
		}
		MPI_Comm this_col;
		MPI_Comm_split(cart_comm, my_col, my_row, &this_col);
		MPI_Comm_free(&cart_comm);

		packed_edge* buf = (packed_edge*)xmalloc(FILE_CHUNKSIZE * sizeof(packed_edge));
		
		MPI_Offset block_limit = (nchunks_in_file + nrows - 1) / nrows;
		
		int my_pos = my_row + my_col * nrows;
		int last_pos = (tg.nglobaledges % ((int64_t)FILE_CHUNKSIZE * nrows * ranks_per_row) != 0) ?
			(tg.nglobaledges / FILE_CHUNKSIZE) % (nrows * ranks_per_row) :
			-1;
		int64_t edges_left = tg.nglobaledges % FILE_CHUNKSIZE;
		int64_t nedges = FILE_CHUNKSIZE * (tg.nglobaledges / ((int64_t)FILE_CHUNKSIZE * nrows * ranks_per_row)) +
			FILE_CHUNKSIZE * (my_pos < (tg.nglobaledges / FILE_CHUNKSIZE) % (nrows * ranks_per_row)) +
			(my_pos == last_pos ? edges_left : 0);
		tg.edgememory_size = nedges;
		tg.edgememory = (packed_edge*)xmalloc(nedges * sizeof(packed_edge));

		MPI_Offset block_idx;
		for (block_idx = 0; block_idx < block_limit; ++block_idx) {
			/* fprintf(stderr, "%d: On block %d of %d\n", rank, (int)block_idx, (int)block_limit); */
			MPI_Offset start_edge_index = int64_min(FILE_CHUNKSIZE * (block_idx * nrows + my_row), tg.nglobaledges);
			MPI_Offset edge_count = int64_min(tg.nglobaledges - start_edge_index, FILE_CHUNKSIZE);
			packed_edge* actual_buf = (block_idx % ranks_per_row == my_col) ?
				tg.edgememory + FILE_CHUNKSIZE * (block_idx / ranks_per_row) :
				buf;

			/* fprintf(stderr, "%d: My range is [%" PRId64 ", %" PRId64 ") %swriting into index %" PRId64 "\n", rank, (int64_t)start_edge_index, (int64_t)(start_edge_index + edge_count), (my_col == (block_idx % ranks_per_row)) ? "" : "not ", (int64_t)(FILE_CHUNKSIZE * (block_idx / ranks_per_row))); */
			if (block_idx % ranks_per_row == my_col) {
				assert (FILE_CHUNKSIZE * (block_idx / ranks_per_row) + edge_count <= tg.edgememory_size);
			}
			
			float* wbuf = (float*)xmalloc(FILE_CHUNKSIZE*sizeof(float));
			weightmemory = (float*)xmalloc(nedges*sizeof(float));
			float* actual_wbuf = (block_idx % ranks_per_row == my_col) ?
				weightmemory + FILE_CHUNKSIZE * (block_idx / ranks_per_row) :
				wbuf;
			generate_kronecker_range(seed, SCALE, start_edge_index, start_edge_index + edge_count, actual_buf);
			
		}
		free(buf);
		MPI_Comm_free(&this_col);
	} else {
		tg.edgememory = NULL;
		tg.edgememory_size = 0;
	}
	MPI_Allreduce(&tg.edgememory_size, &tg.max_edgememory_size, 1, MPI_INT64_T, MPI_MAX, MPI_COMM_WORLD);

	return tg;
}

int64_t *column2;
#define COLUMN2(i) (*(int64_t*)(((char*)column2)+(BYTES_PER_VERTEX*i)) & (int64_t)(0xffffffffffffffffULL>>(64-8*BYTES_PER_VERTEX)))

ResultFromBuilder convert_graph500_csr_to_agl_csr(oned_csr_graph g, ResultFromGenerator generatorResult){

	column2 = g.column;

	ResultFromBuilder builderResult2 = ResultFromBuilder();
    builderResult2.csrGraph = new CyclicCSRGraph(generatorResult);

	int local_vertices= g.nlocalverts;
	if(rank==0){
		local_vertices--;
	}

	builderResult2.csrGraph->setLocalVertices(local_vertices);
	builderResult2.csrGraph->setIndexSize(local_vertices+1);
	int i;
	for(i=0;i <local_vertices; i++){

		builderResult2.csrGraph->setIndexAtPos(i, g.rowstarts[i]);

		for(int j=g.rowstarts[i];j<g.rowstarts[i+1];j++){
			builderResult2.csrGraph->addNeighbors(COLUMN2(j));
		}

	}
	
	builderResult2.csrGraph->setIndexAtPos(i, g.rowstarts[i]);

	std::vector<int> index = builderResult2.csrGraph->getIndex();
    std::vector<int64_t> neighbors = builderResult2.csrGraph->getNeighbors();
	for (int i = 0; i < local_vertices; i++) {

		for(int j=index[i]; j<index[i+1]; j++) {
			int dest_vertex = neighbors[j];
		}
	}

	builderResult2.total_pe = generatorResult.total_pe;
	builderResult2.SCALE = generatorResult.SCALE;
	builderResult2.edgefactor = generatorResult.edgefactor;
	builderResult2.local_edges = g.nlocaledges;
	builderResult2.global_vertices = g.nglobalverts;
	builderResult2.global_edges = generatorResult.global_edges;

	return builderResult2;
}


int main(int argc, char** argv) {
	const char *deps[] = { "system", "bale_actor" };

        aml_init(&argc,&argv); //includes MPI_Init inside
        setup_globals();

	hclib::launch(deps, 2, [=, &argc,&argv] {

		/* Parse arguments. */
		int SCALE = 16;
		int edgefactor = 16; /* nedges / nvertices, i.e., 2*avg. degree */
		if (argc >= 2) SCALE = atoi(argv[1]);
		if (argc >= 3) edgefactor = atoi(argv[2]);
		if (argc <= 1 || argc >= 4 || SCALE == 0 || edgefactor == 0) {
			if (rank == 0) {
				fprintf(stderr, "Usage: %s SCALE edgefactor\n  SCALE = log_2(# vertices) [integer, required]\n  edgefactor = (# edges) / (# vertices) = .5 * (average vertex degree) [integer, defaults to 16]\n(Random number seed and Kronecker initiator are in main.c)\n", argv[0]);
			}
			MPI_Abort(MPI_COMM_WORLD, 1);
		}

		if (rank == 0) {
            fprintf(stderr, "edgefactor=%d, SCALE=%d\n", edgefactor, SCALE);
        }
        
        //generate graph using Graph500 RMAT
        double make_graph_start = MPI_Wtime();
            tuple_graph tg_nonagl = rmatGenerator_non_agl(edgefactor, SCALE);
        double make_graph_stop = MPI_Wtime();
        double make_graph_time_nonagl = make_graph_stop - make_graph_start;
        if (rank == 0) {
            fprintf(stderr, "graph_generation non-agl: %f s\n", make_graph_time_nonagl);
        }	

        //Build graph using Graph500 Cyclic builder
        oned_csr_graph g;
        convert_graph_to_oned_csr(&tg_nonagl, &g);

        //Convert graph500 CSR Graph to AGL CSR Graph
        ResultFromBuilder builderResult2 = convert_graph500_csr_to_agl_csr(g, generatorResult);
        lgp_barrier();

		aml_barrier();
		cleanup_globals();

	});

	return 0;
}