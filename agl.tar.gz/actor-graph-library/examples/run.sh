#!/bin/bash
#SBATCH --job-name=tc_web
#SBATCH -A gts-vsarkar9-coda20
#SBATCH -N64
#SBATCH --ntasks-per-node=24
#SBATCH -t90
#SBATCH -qinferno         
#SBATCH -otc_web_1536.out

echo "Started on `/bin/hostname`"   # prints name of compute node job was started on
cd $SLURM_SUBMIT_DIR                # changes into directory where script was submitted from

srun -N 64 -n 1536 ./tc -f /storage/home/hcoda1/8/ssinghal74/scratch/gaps_dataset/GAP-web/GAP-web.mtx -c

