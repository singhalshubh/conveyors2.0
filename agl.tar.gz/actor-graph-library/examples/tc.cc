#include <algorithm>
#include <vector>

#include <agl.h>

using agl::NodeID;

struct TCMsg {
  NodeID v_to_search;
  NodeID search_target;
};


static inline uint64_t _rdtsc(void) {
    unsigned a, d;
    asm volatile("rdtsc" : "=a" (a), "=d" (d) : : "%rbx", "%rcx");
    return ((uint64_t) a) | (((uint64_t) d) << 32);
}

// struct TCSelector: public hclib::Selector<1, TCMsg> {
//   explicit TCSelector(const agl::CSRGraph &g) : g_(g), local_triangles(0) {
//     mb[0].process = [this](TCMsg m, int sender_rank) {
//       if (g_.is_neigh_of_global(m.v_to_search, m.search_target))
//         local_triangles++;
//     };
//   }

//   // using constraint w < v < u
//   void sendAll() {
//     for (NodeID u_local : g_.local_vertices()) {
//       NodeID u = g_.map_to_global(u_local);
//       for (NodeID v : g_.neigh_global(u_local)) {
//         if (v > u)
//           break;
//         for (NodeID w : g_.neigh_global(u_local)) {
//           if (w > v)
//             break;
//           send(0, {v, w}, g_.map_to_host(v));
//         }
//       }
//     }
//   }

//   int64_t local_triangles;

//  protected:
//   const agl::CSRGraph &g_;
// };

// single-threaded
int64_t TCAlternative(const agl::CSRGraph &g) {
  assert(shmem_n_pes() == 1);
  int64_t total = 0;
  std::vector<NodeID> intersection;
  intersection.reserve(g.get_local_num_nodes());
  for (NodeID u_local : g.local_vertices()) {
    for (NodeID v : g.neigh_global(u_local)) {
      NodeID v_local = g.map_to_local(v);
      auto new_end = std::set_intersection(g.neigh_global(u_local).begin(),
                                           g.neigh_global(u_local).end(),
                                           g.neigh_global(v_local).begin(),
                                           g.neigh_global(v_local).end(),
                                           intersection.begin());
      intersection.resize(new_end - intersection.begin());
      total += intersection.size();
    }
  }
  total = total / 6; 
  return total;
}


void TCVerifier(const agl::CSRGraph &g, const int64_t triangles) {
  int64_t ver_triangles = TCAlternative(g);
  agl::R0Printf("%ld ver_triangles\n", ver_triangles);
  if (triangles == ver_triangles) {
    agl::R0Printf("PASS - total matches verifier\n");
  } else {
    agl::R0Printf("FAIL - total does not matches verifier\n");
  }
}

// int64_t binary_search(int64_t l_, int64_t r_, int64_t val_, const agl::CSRGraph &g) { // custom binary search function
//     while (l_ <= r_) {
//         int m_ = l_ + (r_ - l_) / 2;
//         if (mat_->lnonzero[m_] == val_) { return 1; }
//         if (mat_->lnonzero[m_] < val_) { l_ = m_ + 1; } else { r_ = m_ - 1; }
//     }
//     return 0;
// }

uint64_t pull_cycles = 0;

int64_t numpull = 0;

static int64_t copied_tri_convey_push_process(int64_t* c, convey_t* conv, const agl::CSRGraph &g_, bool done) {
    int64_t k, cnt = 0;
    struct TCMsg m;
    while (convey_pull(conv, &m, NULL) == convey_OK) {
        numpull++;
        uint64_t start = _rdtsc();
        if (g_.is_neigh_of_global(m.v_to_search, m.search_target))
          cnt++;
        pull_cycles += _rdtsc() - start; 
    }
    *c += cnt;
    return convey_advance(conv, done);
}

int64_t TriangleCount(const agl::CSRGraph &g_) {
  uint64_t start = _rdtsc();
  convey_t * conv = convey_new(SIZE_MAX, 0, NULL, 0);
  if (conv == NULL) return(-1);
  if (convey_begin(conv, sizeof(TCMsg), 0) != convey_OK) return(-1);

  int64_t cnt = 0;
  int64_t numpushed = 0;
  uint64_t start_1 = _rdtsc();
  uint64_t start_push = _rdtsc();
  uint64_t tot_push = 0;
  double t1 = wall_seconds();

  TCMsg pkg;
  int64_t k,kk, pe;

  
  for (NodeID u_local : g_.local_vertices()) {
    NodeID u = g_.map_to_global(u_local);
    for (NodeID v : g_.neigh_global(u_local)) {
      if (v > u)
        break;
      for (NodeID w : g_.neigh_global(u_local)) {
        if (w > v)
          break;
        pkg.v_to_search = v;
        pkg.search_target = w;
        uint64_t dest_pe = g_.map_to_host(v);
        if(dest_pe % 24 != MYTHREAD % 24 && dest_pe / 24 != MYTHREAD / 24) {
          numpushed++;
        }
        //tot_push += _rdtsc() - start_push; 
        if (convey_push(conv, &pkg, dest_pe) != convey_OK) {
            copied_tri_convey_push_process(&cnt, conv, g_, 0); 
            --w;
            if(dest_pe % 24 != MYTHREAD % 24 && dest_pe / 24 != MYTHREAD / 24) {
              numpushed--;
            }
        }
        //start_push = _rdtsc();
      }
    }
  }
  while (copied_tri_convey_push_process(&cnt, conv, g_, 1)) {}

  lgp_barrier();
  // Updating count is not necessary since that is taken cared by the mailbox logic
  // *count = cnt;
  minavgmaxD_t stat[1];
  t1 = wall_seconds() - t1;
  lgp_min_avg_max_d( stat, t1, THREADS );
  // fprintf(stderr, "Total-time reported by application: %ld\n", _rdtsc() - start_1);
  // fprintf(stderr, "Pull-time reported by application: %ld\n", pull_cycles);
  // fprintf(stderr, "Push-time reported by application: %ld\n", tot_push);
  // fprintf(stderr, "#pushes/PE: %ld\n", numpushed);
  // fprintf(stderr, "#pushes-total: %ld\n", lgp_reduce_add_l(numpushed));
  // fprintf(stderr, "#pulles: %ld\n", lgp_reduce_add_l(numpull));

  convey_free(conv);
  return lgp_reduce_add_l(cnt);
}


int main(int argc, char** argv) {
  CLIApp cli(argc, argv, "Graph, Build and Count Triangles");
  if (!cli.ParseArgs())
    return -1;

  const char *deps[] = { "system" };

  hclib::launch(deps, 1, [&cli] {
    const agl::CSRGraph g = agl::GraphAndBuild(cli);

    for (int trial=0; trial<1; trial++) {
      auto time_start = agl::start_timer();
      int64_t triangles = TriangleCount(g);
      double tc_time = agl::stop_timer(time_start);
      agl::R0Printf("%ld triangles\n", triangles);
      // if (cli.do_verify())
      //TCVerifier(g, triangles);
      agl::R0PrintTime("tc_time", tc_time);
    }
  });

  return 0;
}
