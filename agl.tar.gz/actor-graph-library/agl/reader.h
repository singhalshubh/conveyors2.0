#ifndef AGL_READER_H_
#define AGL_READER_H_

#include <fstream>
#include <limits>
#include <vector>
#include <algorithm>
#include <utility>
#include <string>

namespace agl {

class Reader {
 public:
  explicit Reader(std::string filename) : filename_(filename),
      global_num_nodes_(0), global_num_edges_(0) {
    ValidateFile();
  }

  std::string GetSuffix() const {
    std::size_t suff_pos = filename_.rfind('.');
    if (suff_pos == std::string::npos) {
      std::cout << "Couldn't find suffix of " << filename_ << std::endl;
      std::exit(-1);
    }
    return filename_.substr(suff_pos);
  }

  std::ifstream Open() const {
    std::ios_base::sync_with_stdio(false);
    std::ifstream file(filename_);
    file.tie(nullptr);
    if (!file.is_open()) {
      std::cout << "Couldn't open file " << filename_ << std::endl;
      std::exit(-2);
    }
    return file;
  }

  void Close(std::ifstream &file) const {
    file.close();
  }

  void ValidateFile() const {
    std::string suffix = GetSuffix();
    if (suffix != ".csv" && suffix != ".txt" && suffix != ".mtx") {
      std::cout << "Unrecognized suffix: " << suffix << std::endl;
      std::exit(-3);
    }
    std::ifstream file = Open();
    Close(file);
  }

  EdgeList ReadInEL(std::ifstream &file) {
    file.seekg(0, std::ios::end);
    size_t fileSize = file.tellg();
    int64_t read_start = (shmem_my_pe() * fileSize) / shmem_n_pes();
    int64_t read_end = ((shmem_my_pe() + 1) * fileSize) / shmem_n_pes();

    file.seekg(read_start, std::ios::beg);
    if (shmem_my_pe() != 0) {
      file.seekg(-1, std::ios::cur);
      file.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    EdgeList el;
    NodeID u, v, local_node_max = 0;
    std::string buf, *end;
    read_start = file.tellg();
    while (read_start < read_end && read_start < fileSize) {  
      getline(file, buf);
      if(buf[0] == '%' || buf[0] == '#') continue;
      read_start += buf.size() + 1;
      std::stringstream ss(buf);
      ss >> v >> u;
      v--;
      u--;
      el.push_back(Edge(u, v));
      local_node_max = std::max(local_node_max, std::max(u, v));
    }
    global_num_edges_ = el.size();
    global_num_nodes_ = lgp_reduce_max_l(local_node_max) + 1;
    return el;
  }

  EdgeChunk ReadFile() {
    auto time_start = start_timer();
    EdgeList el;
    std::string suffix = GetSuffix();
    std::ifstream file = Open();
    if (suffix == ".csv" || suffix == ".txt" || suffix == ".mtx") {
      el = ReadInEL(file);
    } else {
      std::cout << "Unrecognized suffix: " << suffix << std::endl;
      std::exit(-3);
    }
    Close(file);
    double read_graph_time = stop_timer(time_start);
    R0PrintTime("graph_read", read_graph_time);
    return {global_num_nodes_, global_num_edges_, std::move(el)};
  }

 private:
  const std::string filename_;
  NodeID global_num_nodes_;
  size_t global_num_edges_;
};

}  // namespace agl

#endif  // AGL_READER_H_
