#ifndef AGL_GRAPH_H_
#define AGL_GRAPH_H_

#include <algorithm>
#include <memory>
#include <vector>

#include "mapper.h"
#include "util.h"


namespace agl {

class CSRGraph {
 public:
  CSRGraph(std::shared_ptr<Mapper> mapper_ptr, NodeID** index,
           NodeID* neighbors, NodeID local_num_nodes, bool symmetrize,
           NodeID global_num_nodes, size_t global_num_edges) :
    map_(mapper_ptr), index_(index), neighbors_(neighbors),
    local_num_nodes_(local_num_nodes), symmetrize_(symmetrize),
    global_num_nodes(global_num_nodes), global_num_edges(global_num_edges) {}

  ~CSRGraph() {
    if (index_ != nullptr)
      delete[] index_;
    if (neighbors_ != nullptr)
      delete[] neighbors_;
  }

  // Remove copy construction
  CSRGraph(const CSRGraph &other) = delete;

  // Remove assignment (use move below)
  CSRGraph& operator= (CSRGraph &&other) = delete;

  // Prefer move assignment
  CSRGraph(CSRGraph &&other) : map_(other.map_), index_(other.index_),
      neighbors_(other.neighbors_), local_num_nodes_(other.local_num_nodes_),
      symmetrize_(other.symmetrize_), global_num_nodes(other.global_num_nodes),
      global_num_edges(other.global_num_edges) {
    other.index_ = nullptr;
    other.neighbors_ = nullptr;
  }

  NodeID get_local_num_nodes() const {
    return local_num_nodes_;
  }

  size_t get_local_num_edges() const {
    return index_[local_num_nodes_] - index_[0];
  }

  NodeID degree(NodeID v) const {
    return index_[v+1] - index_[v];
  }

  Range<NodeID> local_vertices() const {
    return Range<NodeID>(local_num_nodes_);
  }

  class Neighborhood {
    NodeID *begin_;
    NodeID *end_;
   public:
    Neighborhood(NodeID n, NodeID **ind) :
        begin_(ind[n]), end_(ind[n+1]) {}
    typedef NodeID* iterator;
    iterator begin() { return begin_; }
    iterator end() { return end_; }
  };

  Neighborhood neigh_global(const NodeID n) const {
    assert(n < local_num_nodes_);
    return Neighborhood(n, index_);
  }

  bool is_neigh_of_global(NodeID u, NodeID v) const {
    auto neighs = neigh_global(map_to_local(u));
    return std::binary_search(neighs.begin(), neighs.end(), v);
  }

  class StatefulIter {
    NodeID *curr_;
    NodeID *end_;
   public:
    StatefulIter() : curr_(nullptr), end_(nullptr) {}
    StatefulIter(NodeID n, NodeID **ind) :
        curr_(ind[n]), end_(ind[n+1]) {}
    NodeID value() {
      return *curr_;
    }

    void advance() {
      curr_++;
    }

    NodeID nextAndAdv() {
      NodeID to_return = *curr_;
      curr_++;
      return to_return;
    }

    bool not_done() {
      return curr_ < end_;
    }
  };

  StatefulIter neigh_iter(const NodeID n) const {
    assert(n < local_num_nodes_);
    return StatefulIter(n, index_);
  }

  NodeID map_to_global(NodeID v_local) const {
    return map_->to_global(v_local);
  }

  NodeID map_to_local(NodeID v) const {
    return map_->to_local(v);
  }

  NodeID map_to_host(NodeID v) const {
    return map_->to_host(v);
  }

  std::shared_ptr<Mapper> get_map() const {
    return map_;
  }

  const NodeID global_num_nodes;
  const size_t global_num_edges;
  const bool symmetrize_;

 protected:
  std::shared_ptr<Mapper> map_;
  NodeID** index_;
  NodeID* neighbors_;
  NodeID local_num_nodes_;
};

}  // namespace agl

#endif  // AGL_GRAPH_H_
