#ifndef AGL_GENERATOR_H_
#define AGL_GENERATOR_H_

#include <algorithm>
#include <memory>
#include <random>
#include <vector>
#include <utility>

#include "util.h"


namespace agl {

class Generator {
 public:
  Generator(int scale, int degree, GeneratorType type = GeneratorType::RMAT,
    int block_scale = -1) : // couldn't default block_scale = scale / 2
      scale_(scale), type_(type),
      global_num_nodes_(1l << scale),
      global_num_edges_(global_num_nodes_ * degree),
      block_scale_(block_scale == -1 ? scale / 2 : block_scale),
      block_num_edges_((1l << block_scale_) * degree),
      global_num_blocks_((1l << scale - block_scale_)){
    size_t local_num_blocks = (global_num_blocks_ / shmem_n_pes());
    if (local_num_blocks * shmem_n_pes() + shmem_my_pe() < global_num_blocks_)
      local_num_blocks++;
    local_num_edges_ = local_num_blocks * block_num_edges_;
  }

  EdgeChunk GenerateEL() {
    EdgeChunk edge_chunk = {global_num_nodes_, global_num_edges_};
    auto time_start = start_timer();
    el_.reserve(local_num_edges_);
    if (type_ == GeneratorType::Uniform) {
      R0Printf("Generating Graph using 'Uniform Random' generator\n");
      GenerateUniformEL();
    } else if (type_ == GeneratorType::RMAT) {
      R0Printf("Generating Graph using 'RMAT' generator\n");
      GenerateRMatEL();
    } else {
      R0Printf("Unrecognized GeneratorType (enum)\n");
      exit(-2);
    }
    edge_chunk.el_ptr->swap(el_);
    double make_graph_time = stop_timer(time_start);
    R0PrintTime("graph_generation", make_graph_time);
    return edge_chunk;
  }

  void GenerateRMatEL() {
    const float A = 0.57f, B = 0.19f, C = 0.19f;
    std::mt19937 rng;
    std::uniform_real_distribution<float> udist(0, 1.0f);
    for (size_t block = shmem_my_pe(); block < global_num_blocks_;
      block += shmem_n_pes()) {
      rng.seed(kRandSeed + block);
      for (size_t m = 0; m < block_num_edges_; m++) {
        NodeID src = 0, dst = 0;
        for (NodeID depth=0; depth < scale_; depth++) {
          float rand_point = udist(rng);
          src = src << 1;
          dst = dst << 1;
          if (rand_point < A+B) {
            if (rand_point > A)
              dst++;
          } else {
            src++;
            if (rand_point > A+B+C)
              dst++;
          }
        }
        el_.push_back(Edge(src, dst));
      }
    }
  }

  void GenerateUniformEL() {
    std::mt19937 rng;
    for (size_t block = shmem_my_pe(); block < global_num_blocks_;
      block += shmem_n_pes()) {
      rng.seed(kRandSeed + block);
      std::uniform_int_distribution<int> udist(0, global_num_nodes_-1);
      for (size_t m = 0; m < block_num_edges_; m++) {
        NodeID u = udist(rng);
        NodeID v = udist(rng);
        el_.push_back(Edge(u, v));
      }
    }
  }

 private:
  const int scale_;
  const int block_scale_;
  const NodeID global_num_nodes_;
  const size_t global_num_edges_;
  const size_t global_num_blocks_;
  const size_t block_num_edges_;
  size_t local_num_edges_;
  const GeneratorType type_;
  EdgeList el_;
};

}  // namespace agl

#endif  // AGL_GENERATOR_H_
