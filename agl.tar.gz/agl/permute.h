// #ifndef AGL_PERMUTE_H_
// #define AGL_PERMUTE_H_

// #include <vector>
// #include <algorithm>

// #include "graph.h"
// #include "util.h"

// // Given a CSRGraph, returns a random permutation of its global IDs
// // - Permuation based on Fisher-Yates and is non-deterministic

// // Messaging Plan
// //  * Part 1 - send swap request (main -> MBSwapPart2)
// //  * Part 2 - process first half of swap (MBSwapPart2 -> MBSwapPart3)
// //  * Part 3 - process second half of swap
// //  - Note: if part 2 encounters an aalready outstanding swap, picks new dest


// namespace agl {

//   struct SwapMsg {
//     NodeID u_local;
//     NodeID v_global;
//     NodeID new_v_global;
//   };

//   // SwapPart1 done without a mailbox
//   const int MBSwapPart2 = 0;
//   const int MBSwapPart3 = 1;

//   const NodeID outstanding_limit = 2048l;

//   struct SwapActor: public hclib::Selector<2, SwapMsg> {
//     SwapActor(std::shared_ptr<agl::Mapper> map,
//               std::vector<NodeID> &local_to_new_global, NodeID global_num_nodes) :
//        map(map), local_to_new_global(local_to_new_global),
//        local_dist(0, local_to_new_global.size()-1), global_dist(0, global_num_nodes-1),
//        num_outstanding_(0) {
//       mb[MBSwapPart2].process = [this, &map, &local_to_new_global](SwapMsg m, int sender_pe) {
//         NodeID v_local = map->to_local(m.v_global);
//         // If dest global ID already in a transaction, pick another randomly
//         while (local_to_new_global[v_local] == kLocked)
//           v_local = local_dist(rng);
//         SwapMsg m_to_send = {m.u_local, -1, local_to_new_global[v_local]};
//         local_to_new_global[v_local] = m.new_v_global;
//         send(MBSwapPart3, m_to_send, sender_pe);
//       };
//       mb[MBSwapPart3].process = [this, &local_to_new_global](SwapMsg m, int sender_pe) {
//         assert(local_to_new_global[m.u_local] == kLocked);
//         local_to_new_global[m.u_local] = m.new_v_global;
//         num_outstanding_--;
//       };
//     }

//     void SwapPart1(NodeID u_local) {
//       NodeID rand_dest = global_dist(rng);
//       SwapMsg m = {u_local, rand_dest, local_to_new_global[u_local]};
//       local_to_new_global[u_local] = kLocked;
//       send(MBSwapPart2, m, map->to_host(rand_dest));
//     }

//     NodeID kLocked = -1;

//     std::shared_ptr<agl::Mapper> map;
//     std::vector<NodeID> &local_to_new_global;
//     std::mt19937 rng;
//     std::uniform_int_distribution<NodeID> local_dist;
//     std::uniform_int_distribution<NodeID> global_dist;

//     NodeID num_outstanding_;
//   };

//   // returns vec of local -> new global
//   std::vector<NodeID> GenRandRelabel(const agl::CSRGraph &g) {
//     std::vector<NodeID> local_to_new_global;
//     local_to_new_global.reserve(g.get_local_num_nodes());
//     for (NodeID u_local : g.local_vertices())
//       local_to_new_global.push_back(g.map_to_global(u_local));
//     // fill in for possible 0-degree vertices in PE's allocation with high IDs
//     // NOTE: assumes local -> global mapping is monotonically increasing
//     for (NodeID u_local=g.get_local_num_nodes();
//          g.map_to_global(u_local) < g.global_num_nodes; u_local++) {
//       local_to_new_global.push_back(g.map_to_global(u_local));
//     }
//     SwapActor sa(g.get_map(), local_to_new_global, g.global_num_nodes);
//     hclib::finish([&sa, &g, &local_to_new_global] {
//       NodeID actual_num_local_nodes = local_to_new_global.size();
//       NodeID max_outstanding = std::min(actual_num_local_nodes/2,
//                                         outstanding_limit);
//       sa.start();
//       for (NodeID u_local : g.local_vertices()) {
//         if (sa.num_outstanding_ < max_outstanding) {
//           sa.num_outstanding_++;
//           sa.SwapPart1(u_local);
//         } else {
//           hclib::yield_at(nic);
//         }
//       }
//       sa.done(0);
//     });
//     return local_to_new_global;
//   }
// }  // namespace agl

// #endif  // AGL_PERMUTE_H_
