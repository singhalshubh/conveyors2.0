#ifndef AGL_TERMINATE_H_
#define AGL_TERMINATE_H_

namespace agl {
// NOTE: depends on hclib much more than agl, but packaged within agl

class RemainingTerminator {
  int64_t num_local_remaining_;

 public:
  RemainingTerminator(int64_t starting_remaining=0) :
    num_local_remaining_(starting_remaining) {}

  void DecRemaining(int64_t to_decrement=1) {
    num_local_remaining_ -= to_decrement;
  }

  void PollAndYieldForAll() {
    int num_attempts = 0;
    while(1) {
      assert(num_local_remaining_ >= 0);
      num_attempts++;
      bool more_to_send = num_local_remaining_ > 0;
      int64_t pes_active = lgp_reduce_add_l(more_to_send ? 1 : 0);
      // agl::R0Printf("PEs Active: %lld\n", pes_active);
      if (pes_active == 0) {
        break;
        // Caller should call done() on selector
      } else
        hclib::yield_at(nic);
    }
    R0Printf("# Attempts: %d\n", num_attempts);
  }

  void LocalPollAndYield() {
    int num_attempts = 0;
    while(1) {
      num_attempts++;
      if (num_local_remaining_ > 0)
        hclib::yield_at(nic);
      else
        break;
    }
    R0Printf("# Attempts: %d\n", num_attempts);
  }
};

}  // namespace agl

#endif  // AGL_TERMINATE_H_
