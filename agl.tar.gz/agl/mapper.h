#ifndef AGL_MAPPER_H_
#define AGL_MAPPER_H_

#include <algorithm>
#include <vector>

#include "util.h"


namespace agl {

class Mapper {
 public:
  Mapper() : Mapper(shmem_my_pe(), shmem_n_pes()) {}

  Mapper(NodeID pe, NodeID num_pes) : pe_(pe), num_pes_(num_pes) {}

  virtual NodeID to_global(NodeID v_local) const = 0;

  virtual NodeID to_local(NodeID v) const = 0;

  virtual NodeID to_host(NodeID v) const = 0;

  virtual const char* name() const { return "Abstract"; }

 protected:
  const NodeID pe_;
  const NodeID num_pes_;
};


// Impractical for graphs, intended for benchmarking
class IdentityMapper : public Mapper {
 public:
  using Mapper::Mapper;

  virtual NodeID to_global(NodeID v_local) const {
    return v_local;
  }

  virtual NodeID to_local(NodeID v) const {
    return v;
  }

  virtual NodeID to_host(NodeID v) const {
    return v;
  }

  virtual const char* name() const { return "Identity"; }
};


class CyclicMapper : public Mapper {
 public:
  CyclicMapper() : Mapper(), log_num_pes_(int_log2(num_pes_)),
      mask_(num_pes_ - 1), pow2_(is_pow2(num_pes_)) {}

  CyclicMapper(NodeID pe, NodeID num_pes) : Mapper(pe, num_pes),
      log_num_pes_(int_log2(num_pes_)), mask_(num_pes_ - 1),
      pow2_(is_pow2(num_pes_)) {}

  virtual NodeID to_global(NodeID v_local) const {
    if (pow2_)
      return (v_local << log_num_pes_) + pe_;
    else
      return v_local * num_pes_ + pe_;
  }

  virtual NodeID to_local(NodeID v) const {
    if (pow2_)
      return v >> log_num_pes_;
    else
      return v / num_pes_;
  }

  virtual NodeID to_host(NodeID v) const {
    if (pow2_)
      return v & mask_;
    else
      return v % num_pes_;
  }

  virtual const char* name() const { return "Cyclic"; }

 protected:
  const bool pow2_;
  const NodeID log_num_pes_;
  const NodeID mask_;
};


class RangeMapper : public Mapper {
 public:
  explicit RangeMapper(NodeID num_nodes) : Mapper(),
      v_per_node_(roundup_divide(num_nodes, num_pes_)),
      pow2_(is_pow2(v_per_node_)),
      mask_(v_per_node_ - 1), log_v_per_node_(int_log2(v_per_node_)) {}

  RangeMapper(NodeID num_nodes, NodeID pe, NodeID num_pes) :
      Mapper(pe, num_pes),
      v_per_node_(roundup_divide(num_nodes, num_pes_)),
      pow2_(is_pow2(v_per_node_)),
      mask_(v_per_node_ - 1), log_v_per_node_(int_log2(v_per_node_)) {}

  NodeID to_global(NodeID v_local) const {
    if (pow2_)
      return (pe_ << log_v_per_node_) + v_local;
    else
      return pe_ * v_per_node_ + v_local;
  }

  NodeID to_local(NodeID v) const {
    if (pow2_)
      return v & mask_;
    else
      return v % v_per_node_;
  }

  NodeID to_host(NodeID v) const {
    if (pow2_)
      return v >> log_v_per_node_;
    else
      return v / v_per_node_;
  }

  virtual const char* name() const { return "Range"; }

 private:
  const NodeID v_per_node_;
  const bool pow2_;
  const NodeID log_v_per_node_;
  const NodeID mask_;
};


// XOR reduction into needed number of bits
class XORMapper : public CyclicMapper {
 public:
  explicit XORMapper(NodeID num_nodes) : CyclicMapper() {
    init(num_nodes);
  }

  XORMapper(NodeID num_nodes, NodeID pe, NodeID num_pes) :
      CyclicMapper(pe, num_pes) {
    init(num_nodes);
  }

  void init(NodeID num_nodes) {
    assert(pow2_);
    int bits_left = int_log2(num_nodes);
    if (log_num_pes_ == 0) {
      shamts_.push_back(bits_left);
    } else {
      while (bits_left > log_num_pes_) {
        if (bits_left / 2 >= log_num_pes_) {
          shamts_.push_back(bits_left/2);
          bits_left = roundup_divide(bits_left, 2);
        } else {
          int next_shamt = std::min(log_num_pes_, bits_left - log_num_pes_);
          bits_left -= next_shamt;
          shamts_.push_back(next_shamt);
        }
      }
    }
    // std::cout << pe_ << ": ";
    // for (int shamt : shamts) {
    //   std::cout << "  " << shamt;
    // }
    // std::cout << std::endl;
  }

  virtual NodeID to_global(NodeID v_local) const {
    NodeID lower = to_host(v_local << log_num_pes_);
    lower ^= pe_;
    // handle smeared bits from overlapped final shift and XOR
    if (shamts_.back() < log_num_pes_) {
      NodeID fixup_mask = 1l << (log_num_pes_ - 1);
      NodeID limit = 1l << shamts_.back();
      for (fixup_mask; fixup_mask >= limit; fixup_mask >>= 1) {
        lower ^= (lower & fixup_mask) >> shamts_.back();
      }
    }
    return (v_local << log_num_pes_) | (lower & mask_);
  }

  virtual NodeID to_local(NodeID v) const {
    return v >> log_num_pes_;
  }

  virtual NodeID to_host(NodeID v) const {
    for (int shamt : shamts_) {
      v ^= (v >> shamt);
    }
    return v & mask_;
  }

  virtual const char* name() const { return "XOR"; }

 protected:
  std::vector<int> shamts_;
};


// cyclic but flip alternatively
class SnakeMapper : public CyclicMapper {
 public:
  using CyclicMapper::CyclicMapper;

  NodeID to_global(NodeID v_local) const {
    if (is_even(v_local)) {
      if (pow2_)
        return (v_local << log_num_pes_) + pe_;
      else
        return v_local * num_pes_ + pe_;
    } else {
      if (pow2_)
        return (v_local << log_num_pes_) + ((num_pes_ - pe_ - 1) &mask_);
      else
        return v_local*num_pes_ + (num_pes_ - pe_ - 1) % num_pes_;
    }
  }

  NodeID to_local(NodeID v) const {
    if (pow2_)
      return v >> log_num_pes_;
    else
      return v / num_pes_;
  }

  NodeID to_host(NodeID v) const {
    if (pow2_) {
      NodeID round = v >> log_num_pes_;
      if (is_even(round))
        return v & mask_;
      else
        return (num_pes_ - (v&mask_) - 1) & mask_;
    } else {
      NodeID round = v / num_pes_;
      if (is_even(round))
        return v % num_pes_;
      else
        return (num_pes_ - (v%num_pes_) - 1) % num_pes_;
    }
  }

  virtual const char* name() const { return "Snake"; }
};


// cyclic but rotate by 1
class RotationMapper : public CyclicMapper {
 public:
  using CyclicMapper::CyclicMapper;

  NodeID to_global(NodeID v_local) const {
    if (pow2_) {
      NodeID offset = v_local & mask_;
      return (v_local << log_num_pes_) + ((pe_ - offset + num_pes_) & mask_);
    } else {
      NodeID offset = v_local % num_pes_;
      return v_local * num_pes_ + (pe_ - offset + num_pes_) % num_pes_;
    }
  }

  NodeID to_local(NodeID v) const {
    if (pow2_)
      return v >> log_num_pes_;
    else
      return v / num_pes_;
  }

  NodeID to_host(NodeID v) const {
    if (pow2_) {
      NodeID offset = v >> log_num_pes_;
      return (v + offset) & mask_;
    } else {
      NodeID offset = v / num_pes_;
      return (v + offset) % num_pes_;
    }
  }

  virtual const char* name() const { return "Rotation"; }
};


// cyclic but flip and move by 1 alternatively
class SnakeRotationMapper : public CyclicMapper {
 public:
  using CyclicMapper::CyclicMapper;

  NodeID to_global(NodeID v_local) const {
    if (pow2_) {
      NodeID offset = (v_local >> 1) & mask_;
      if (is_even(v_local)) {
        return (v_local << log_num_pes_) + ((pe_ - offset + num_pes_) & mask_);
      } else {
        return (v_local << log_num_pes_) +
               ((num_pes_ + offset - (pe_&mask_) - 1) & mask_);
      }
    } else {
      NodeID offset = (v_local/2) % num_pes_;
      if (is_even(v_local)) {
        return v_local*num_pes_ + (pe_ - offset + num_pes_) % num_pes_;
      } else {
        return v_local*num_pes_ + (num_pes_ + offset - (pe_%num_pes_) - 1)
               % num_pes_;
      }
    }
  }

  NodeID to_local(NodeID v) const {
    if (pow2_)
      return v >> log_num_pes_;
    else
      return v / num_pes_;
  }

  NodeID to_host(NodeID v) const {
    if (pow2_) {
      NodeID round = v >> log_num_pes_;
      NodeID offset = (round >> 1) & mask_;
      if (is_even(round)) {
        return (offset + v) & mask_;
      } else {
        return (num_pes_ + offset - (v&mask_) - 1) & mask_;
      }
    } else {
      NodeID round = v / num_pes_;
      NodeID offset = (round/2) % num_pes_;
      if (is_even(round)) {
        return (offset + v) % num_pes_;
      } else {
        return (num_pes_ + offset - (v%num_pes_) - 1) % num_pes_;
      }
    }
  }

  virtual const char* name() const { return "SnakeRotation"; }
};

}  // namespace agl

#endif  // AGL_MAPPER_H_
