#ifndef AGL_COMMAND_LINE_H_
#define AGL_COMMAND_LINE_H_

#include <getopt.h>
#include <string>
#include <vector>

class CLI {
 protected:
  int argc_;
  char** argv_;
  std::string name_;
  std::string get_args_ = "hf:eu:g:k:crx";
  std::vector<std::string> help_strings_;

  std::string filename_ = "";
  bool symmetrize_ = true;
  agl::GeneratorType gen_type_ = agl::GeneratorType::RMAT;
  int scale_ = -1;
  int degree_ = 16;
  agl::MapperType map_type_ = agl::MapperType::Auto;

  void AddHelpLine(char opt, std::string opt_arg, std::string text,
                   std::string def = "") {
    const int kBufLen = 100;
    char buf[kBufLen];
    if (opt_arg != "")
      opt_arg = "<" + opt_arg + ">";
    if (def != "")
      def = "[" + def + "]";
    snprintf(buf, kBufLen, " -%c %-9s: %-54s%10s", opt, opt_arg.c_str(),
            text.c_str(), def.c_str());
    help_strings_.push_back(buf);
  }

 public:
  CLI(int argc, char** argv, std::string name = "") :
         argc_(argc), argv_(argv), name_(name) {
    AddHelpLine('h', "", "print this help message");
    AddHelpLine('f', "file", "load graph from file");
    AddHelpLine('e', "", "skip symmetrize input edge list", "false");
    AddHelpLine('u', "scale", "generate 2^scale 'Uniform Random' graph");
    AddHelpLine('g', "scale", "generate 2^scale 'R-MAT' graph");
    AddHelpLine('k', "degree", "average degree for synthetic graph",
                std::to_string(degree_));
    AddHelpLine('c', "", "use 'Cyclic' mapper");
    AddHelpLine('r', "", "use 'Range' mapper");
    AddHelpLine('x', "", "use 'XOR' mapper");
  }

  bool ParseArgs() {
    signed char c_opt;
    while ((c_opt = getopt(argc_, argv_, get_args_.c_str())) != -1) {
      HandleArg(c_opt, optarg);
    }
    if (filename_.empty() && scale_ == -1) {
      PrintUsage();
      return false;
    }
    return true;
  }

  void virtual HandleArg(signed char opt, char* opt_arg) {
    switch (opt) {
      default:
      case 'h': PrintUsage();                               break;
      case 'f': filename_ = std::string(opt_arg);           break;
      case 'e': symmetrize_ = false;                        break;
      case 'u': gen_type_ = agl::GeneratorType::Uniform;
                scale_ = atoi(opt_arg);                     break;
      case 'g': scale_ = atoi(opt_arg);                     break;
      case 'k': degree_ = atoi(opt_arg);                    break;
      case 'c': map_type_ = agl::MapperType::Cyclic;        break;
      case 'r': map_type_ = agl::MapperType::Range;         break;
      case 'x': map_type_ = agl::MapperType::XOR;           break;
    }
  }

  void PrintUsage() {
    std::cout << name_ << std::endl;
    for (std::string h : help_strings_)
      std::cout << h << std::endl;
    std::exit(0);
  }

  std::string filename() const { return filename_; }
  bool symmetrize() const { return symmetrize_; }
  agl::GeneratorType gen_type() const { return gen_type_; }
  int scale() const { return scale_; }
  int degree() const { return degree_; }
  agl::MapperType map_type() const { return map_type_; }
};


class CLIApp : public CLI {
  int num_trials_ = 1;
  bool do_verify_ = false;
 public:
  CLIApp(int argc, char** argv, std::string name) : CLI(argc, argv, name) {
    get_args_ += "n:v";
    AddHelpLine('n', "n", "perform n trials", std::to_string(num_trials_));
    AddHelpLine('v', "", "verify the output of each run", "false");
  }

  void HandleArg(signed char opt, char* opt_arg) override {
    switch (opt) {
      case 'n': num_trials_ = atoi(opt_arg);            break;
      case 'v': do_verify_ = true;                      break;
      default: CLI::HandleArg(opt, opt_arg);
    }
  }

 int num_trials() const { return num_trials_; }
 bool do_verify() const { return do_verify_; }
};

#endif  // AGL_COMMAND_LINE_H_
