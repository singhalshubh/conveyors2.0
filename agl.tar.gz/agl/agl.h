#ifndef AGL_AGL_H_
#define AGL_AGL_H_

#include <shmem.h>
extern "C" {
  #include <libgetput.h>
}
#include <selector.h>

#include "generator.h"
#include "builder.h"

#endif  // AGL_AGL_H_
