#ifndef AGL_COLLECTIVES_H_
#define AGL_COLLECTIVES_H_

#include <vector>

#include <selector.h>


namespace agl {

// template <typename T_>
// class GatherSelector: public hclib::Selector<1, T_> {
//  public:
//    explicit GatherSelector(int dest_pe) {
//     if (shmem_my_pe() == dest_pe)
//       result.resize(shmem_n_pes());
//     hclib::Selector<1, T_>::mb[0].process = [this](T_ m, int64_t sender_pe) {
//       assert(sender_pe < result.size());
//       result[sender_pe] = m;
//     };
//   }

//   std::vector<T_> result;
// };


// template <typename T_>
// std::vector<T_> GatherVec(T_ word_to_gather, int64_t dest_pe = 0) {
//   GatherSelector<T_> gs(dest_pe);
//   hclib::finish([&gs, word_to_gather, dest_pe] {
//     gs.start();
//     gs.send(0, word_to_gather, dest_pe);
//     gs.done(0);
//   });
//   return gs.result;
// }

}  // namespace agl

#endif  // AGL_COLLECTIVES_H_
