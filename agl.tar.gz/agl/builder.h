#ifndef AGL_BUILDER_H_
#define AGL_BUILDER_H_

#include <algorithm>
#include <memory>
#include <vector>

#include "balance_analysis.h"
#include "graph.h"
#include "reader.h"
#include "command_line.h"

namespace agl {

struct BuilderSelector: public hclib::Selector<1, BuilderEdgeMsg> {
  BuilderSelector(std::shared_ptr<Mapper> map, AdjList *adj_list_ptr) {
    mb[0].process = [&map, adj_list_ptr](BuilderEdgeMsg m, int sender_rank) {
      NodeID v_local = map->to_local(m.src);
      if (v_local >= adj_list_ptr->size())
        adj_list_ptr->resize(v_local+1);
      (*adj_list_ptr)[v_local].push_back(m.dst);
    };
  }
};


class Builder {
 public:
  Builder(EdgeChunk &edge_chunk, MapperType type = MapperType::Cyclic,
          const bool symmetrize = true) :
          edge_chunk_(edge_chunk),
          symmetrize_(symmetrize) {
    if (type == MapperType::Cyclic)
      map_ = std::make_shared<CyclicMapper>();
    else if (type == MapperType::Range)
      map_ = std::make_shared<RangeMapper>(edge_chunk_.global_num_nodes);
    else if (type == MapperType::Snake)
      map_ = std::make_shared<SnakeMapper>();
    else if (type == MapperType::Rotation)
      map_ = std::make_shared<RotationMapper>();
    else if (type == MapperType::SnakeRot)
      map_ = std::make_shared<SnakeRotationMapper>();
    else if (type == MapperType::XOR)
      map_ = std::make_shared<XORMapper>(edge_chunk_.global_num_nodes);
    else if (type == MapperType::Auto)
      if (is_pow2(shmem_n_pes()))
        map_ = std::make_shared<XORMapper>(edge_chunk_.global_num_nodes);
      else
        map_ = std::make_shared<CyclicMapper>();
    else
      exit(-10);
  }

  // NOTE: this will free the internals of the EdgeChunk as it runs
  CSRGraph BuildCSRGraph() const {
    R0Printf("Building Graph using '%s' builder\n", map_->name());
    AdjList adj_list;
    auto time_start = start_timer();
    BuilderSelector *bgs = new BuilderSelector(map_, &adj_list);
    hclib::finish([bgs, this] {
      bgs->start();
      // distribute edges
      for (Edge e : *(edge_chunk_.el_ptr)) {
        if (e.first == e.second)  // drop self loops
          continue;
        bgs->send(0, {e.first, e.second}, map_->to_host(e.first));
        if (symmetrize_)
          bgs->send(0, {e.second, e.first}, map_->to_host(e.second));
      }
      bgs->done(0);
    });
    // Free EL early to reduce peak memory consumption
    edge_chunk_.el_ptr.reset();
    SquishAdjList(&adj_list);
    CSRGraph csrGraph = MakeCSR(adj_list);
    double build_graph_time = stop_timer(time_start);
    R0PrintTime("construction_time", build_graph_time);
    //CalcAndPrintGraphBalance(csrGraph);
    return csrGraph;
  }

 protected:
  void SquishAdjList(AdjList *adj_list_ptr) const {
    for (NodeID n=0; n < adj_list_ptr->size(); n++) {
      std::vector<NodeID> &nl = (*adj_list_ptr)[n];
      std::sort(nl.begin(), nl.end());
      nl.erase(std::unique(nl.begin(), nl.end()), nl.end());
      // nl.erase(std::remove(nl.begin(), nl.end(), n), nl.end());
    }
  }

  CSRGraph MakeCSR(const AdjList &adj_list) const {
    NodeID num_nodes = adj_list.size();
    std::vector<size_t> offsets;
    offsets.reserve(num_nodes);
    size_t degreePrefixSum = 0;
    for (NodeID v=0; v < num_nodes; v++) {
      offsets.push_back(degreePrefixSum);
      degreePrefixSum += adj_list[v].size();
    }
    NodeID **index = new NodeID*[num_nodes+1];
    NodeID *neighs = new NodeID[degreePrefixSum];
    for (NodeID u=0; u < num_nodes; u++) {
      index[u] = neighs + offsets[u];
      std::copy(adj_list[u].begin(), adj_list[u].end(), index[u]);
    }
    index[num_nodes] = neighs + degreePrefixSum;
    size_t global_num_edges = lgp_reduce_add_l(degreePrefixSum);
    return CSRGraph(map_, index, neighs, num_nodes, symmetrize_,
                    edge_chunk_.global_num_nodes, global_num_edges);
  }

  EdgeChunk &edge_chunk_;
  std::shared_ptr<Mapper> map_;
  const bool symmetrize_;
};


CSRGraph GenerateAndBuild(int scale, int degree,
                          GeneratorType gen_type = GeneratorType::RMAT,
                          MapperType map_type = MapperType::Auto,
                          bool symmetrize = true) {
  Generator rgenerator(scale, degree, gen_type);
  EdgeChunk edge_chunk = rgenerator.GenerateEL();
  Builder builder(edge_chunk, map_type, symmetrize);
  return builder.BuildCSRGraph();
}


CSRGraph ReadAndBuild(std::string filename,
                      MapperType map_type = MapperType::Auto,
                      bool symmetrize = true) {
  Reader reader(filename);
  EdgeChunk edge_chunk = reader.ReadFile();
  Builder builder(edge_chunk, map_type, symmetrize);
  return builder.BuildCSRGraph();
}


CSRGraph GraphAndBuild(const CLI &cli) {
  EdgeChunk edge_chunk = [&cli] {
    if (!cli.filename().empty()) {
      Reader reader(cli.filename());
      return reader.ReadFile();
    } else {
      Generator rgenerator(cli.scale(), cli.degree(), cli.gen_type());
      return rgenerator.GenerateEL();
    }
  }();
  Builder builder(edge_chunk, cli.map_type(), cli.symmetrize());
  return builder.BuildCSRGraph();
}

}  // namespace agl

#endif  // AGL_BUILDER_H_
