#ifndef AGL_UTIL_H_
#define AGL_UTIL_H_

#include <chrono>
#include <cstdarg>
#include <string>

#include <shmem.h>


namespace agl {

typedef int64_t NodeID;
typedef std::pair<NodeID, NodeID> Edge;
typedef std::vector<Edge> EdgeList;
typedef std::vector<std::vector<NodeID>> AdjList;

struct EdgeChunk {
  const NodeID global_num_nodes;
  const size_t global_num_edges;
  std::shared_ptr<EdgeList> el_ptr;

  EdgeChunk(NodeID init_num_nodes, size_t init_num_edges) :
    global_num_nodes(init_num_nodes), global_num_edges(init_num_edges),
    el_ptr(std::make_shared<EdgeList>()) {}
};

struct BuilderEdgeMsg {
  NodeID src;
  NodeID dst;
};

enum class GeneratorType {
  Uniform = 1,
  RMAT = 2,
};

enum class MapperType {
  Cyclic = 1,
  Range = 2,
  Snake = 3,
  Rotation = 4,
  SnakeRot = 5,
  XOR = 6,
  Auto = 7,
};

static const int64_t kRandSeed = 27491095;

// Printing
void R0Printf(const char *printf_format, ...) {
  if (shmem_my_pe() == 0) {
    va_list args;
    va_start(args, printf_format);
    vprintf(printf_format, args);
    va_end(args);
  }
}

void R0PrintTime(const std::string &s, double seconds) {
  R0Printf("%-21s%3.5lf\n", (s + ":").c_str(), seconds);
}


// Timing
std::chrono::high_resolution_clock::time_point start_timer() {
  return std::chrono::high_resolution_clock::now();
}

double stop_timer(const std::chrono::high_resolution_clock::time_point &start) {
  auto stop = std::chrono::high_resolution_clock::now();
  auto diff = stop - start;
  return std::chrono::duration_cast<std::chrono::duration<double>>(diff).count();
}


// Math
bool is_even(NodeID x) {
  return !(x&1);
}

bool is_pow2(NodeID x) {
  return !(x & (x - 1));
}

NodeID int_log2(NodeID x) {
  int log_x = 0;
  while ((1l << log_x) < x) {
    log_x++;
  }
  return log_x;
}

NodeID roundup_divide(NodeID numerator, NodeID denominator) {
  return (numerator + denominator - 1) / denominator;
}


// Iterator Sugar
template <typename T_>
class RangeIter {
  T_ x_;
 public:
  explicit RangeIter(T_ x) : x_(x) {}
  bool operator!=(RangeIter const& other) const { return x_ != other.x_; }
  T_ const& operator*() const { return x_; }
  RangeIter& operator++() {
    ++x_;
    return *this;
  }
};

template <typename T_>
class Range {
  T_ from_;
  T_ to_;
 public:
  explicit Range(T_ to) : from_(0), to_(to) {}
  Range(T_ from, T_ to) : from_(from), to_(to) {}
  RangeIter<T_> begin() const { return RangeIter<T_>(from_); }
  RangeIter<T_> end() const { return RangeIter<T_>(to_); }
};

}  // namespace agl

#endif  // AGL_UTIL_H_
