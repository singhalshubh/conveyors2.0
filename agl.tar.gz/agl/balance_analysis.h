#ifndef AGL_BALANCE_ANALYSIS_H_
#define AGL_BALANCE_ANALYSIS_H_

#include <algorithm>
#include <vector>
#include <bits/stdc++.h>

#include "collectives.h"
#include "graph.h"


namespace agl {

// // return the edge-ID balance for this PE
// // (mean local NodeID (scaled from 0 to 1) of local directed edges)
// // numbers close to 0 imply high degree vertices have small local NodeID
// // numbers close to 1 imply high degree vertices have large local NodeID
// double edgeIDbalance(const CSRGraph &g) {
//   size_t num_edges = 0;
//   size_t sum_vertices = 0;
//   for (NodeID u_local : g.local_vertices()) {
//     int num_neighbors = g.degree(u_local);
//     num_edges += num_neighbors;
//     sum_vertices += u_local * num_neighbors;
//   }
//   return static_cast<double>(sum_vertices) /
//       (num_edges * (g.get_local_num_nodes() - 1));
// }

// // return the edgecut for this PE
// // (total number of outgoing edges)
// size_t edgecut(const CSRGraph &g) {
//   size_t cut = 0;
//   for (NodeID u_local : g.local_vertices()) {
//     for (NodeID v : g.neigh_global(u_local)) {
//       if (g.map_to_host(v) != shmem_my_pe())
//         cut++;
//     }
//   }
//   return cut;
// }

// // return the transposed communication volume for this PE
// // (total number of non-local vertices
// //  connected to 1 or more local vertex)
// size_t commVolT(const CSRGraph &g) {
//   std::unordered_set<NodeID> n_set; // set of non-local neighbors
//   for (NodeID u_local : g.local_vertices()) {
//     for (NodeID v : g.neigh_global(u_local)) {
//       if (g.map_to_host(v) != shmem_my_pe())
//         n_set.insert(v);
//     }
//   }
//   return n_set.size();
// }

// // return the communication volume for this PE
// // (sum over each local vertex of
// //  the number of other PEs it has at least 1 neighbor in)
// size_t commVol(const CSRGraph &g) {
//   std::unordered_set<NodeID> pe_set; // set of non-local PEs
//   size_t comm_v = 0;
//   for (NodeID u_local : g.local_vertices()) {
//     for (NodeID v : g.neigh_global(u_local)) {
//       NodeID npe = g.map_to_host(v);
//       if (npe != shmem_my_pe())
//         pe_set.insert(npe);
//     }
//     comm_v += pe_set.size();
//     pe_set.clear();
//   }
//   return comm_v;
// }

// int64_t CalcTotal(const std::vector<int64_t> &values) {
//   int64_t total = 0;
//   for (int64_t x : values) {
//     total += x;
//   }
//   return total;
// }

// template <class T>
// void CalcAndPrintBalance(const std::vector<T> &values) {
//   T total = 0;
//   T min = values[0];
//   T max = values[0];
//   for (T x : values) {
//     total += x;
//     min = std::min(min, x);
//     max = std::max(max, x);
//   }
//   T average = total / values.size();
//   std::stringstream bal;
//   bal << std::fixed << std::setprecision(5);
//   bal << "  Mean: " << std::setw(12) << average << "\n"
//       << "  Max:  " << std::setw(12) << max
//       << " (" << static_cast<double>(max) / average << ")\n"
//       << "  Min:  " << std::setw(12) << min
//       << " (" << static_cast<double>(min) / average << ")\n";
//   printf("%s", bal.str().c_str());
// }

// void CalcAndPrintGraphBalance(const CSRGraph &g, const bool cut_analysis=false) {
//   const NodeID stats_pe = 0;
//   std::vector<int64_t> pe_to_total_edges =
//       GatherVec<int64_t>(g.get_local_num_edges(), stats_pe);
//   std::vector<int64_t> pe_to_total_nodes =
//       GatherVec<int64_t>(g.get_local_num_nodes(), stats_pe);
//   std::vector<int64_t> pe_to_total_edgecut;
//   std::vector<int64_t> pe_to_total_commVolT;
//   std::vector<int64_t> pe_to_total_commVol;
//   std::vector<double> pe_to_total_edgeIDbalance;
//   if (cut_analysis) {
//     pe_to_total_edgecut = GatherVec<int64_t>(edgecut(g), stats_pe);
//     pe_to_total_commVolT = GatherVec<int64_t>(commVolT(g), stats_pe);
//     pe_to_total_commVol = GatherVec<int64_t>(commVol(g), stats_pe);
//     pe_to_total_edgeIDbalance  = GatherVec<double>(edgeIDbalance(g), stats_pe);
//   }
//   if (shmem_my_pe() == stats_pe) {
//     printf("Total Nodes: %lu\n", g.global_num_nodes);
//     printf("Total Edges: %lu\n", g.global_num_edges / (g.symmetrize_ ? 2 : 1));
//     if (cut_analysis) {
//       printf("Total Edgecut: %lu\n", CalcTotal(pe_to_total_edgecut) / 2);
//       printf("Total Communication Volume: %lu\n", CalcTotal(pe_to_total_commVol));
//     }
//     printf("Using %u PEs\n", shmem_n_pes());
//     printf("Edges per PE\n");
//     CalcAndPrintBalance(pe_to_total_edges);
//     printf("Vertices per PE\n");
//     CalcAndPrintBalance(pe_to_total_nodes);
//     if (cut_analysis) {
//       printf("Edgecut per PE\n");
//       CalcAndPrintBalance(pe_to_total_edgecut);
//       printf("Communication Volume -T per PE\n");
//       CalcAndPrintBalance(pe_to_total_commVolT);
//       printf("Communication Volume per PE\n");
//       CalcAndPrintBalance(pe_to_total_commVol);
//       printf("Edge-ID balance per PE\n");
//       CalcAndPrintBalance(pe_to_total_edgeIDbalance);
//     }
//   }
// }

}  // namespace agl

#endif  // AGL_BALANCE_ANALYSIS_H_
