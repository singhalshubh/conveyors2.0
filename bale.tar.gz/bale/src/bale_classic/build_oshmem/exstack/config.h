/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define if shmem_alltoallv exists. */
/* #undef HAVE_SHMEMX_ALLTOALLV */

/* Define if shmem_putmem_signal exists. */
/* #undef HAVE_SHMEMX_PUTMEM_SIGNAL */

/* Define if shmem_team_alltoallv exists. */
/* #undef HAVE_SHMEMX_TEAM_ALLTOALLV */

/* Define if shmem_free exists. */
#define HAVE_SHMEM_FREE 1

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "bale@super.org"

/* Define to the full name of this package. */
#define PACKAGE_NAME "exstack"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "exstack 1.0.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "exstack"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0.0"
