#line 1 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/accel.c"
// Copyright (c) 2020, Institute for Defense Analyses
// 4850 Mark Center Drive, Alexandria, VA 22311-1882; 703-845-2500
//
// All rights reserved.
//
// This file is part of the conveyor package. For license information,
// see the LICENSE file in the top level directory of the distribution.


// SUMMARY: Accelerated push, pull, and pivot functions for tensor conveyors
// that exploit knowledge of tag size, item size, and porter internals.


#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include "convey_impl.h"
#include "porter_impl.h"
#include "private.h"
#include "tensor.h"
#define ROUTER_HINT inline
#include "router.h"


#line 27

#line 29
#line 30

static inline bool
porter_push_0_4(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 0 > 0
    *(void*)(area->next) = (void) tag;
#endif
    memcpy(area->next + 0, item, 4);
    area->next += 4;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_1_4(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 1 > 0
    *(uint8_t*)(area->next) = (uint8_t) tag;
#endif
    memcpy(area->next + 1, item, 4);
    area->next += 5;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_2_4(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 2 > 0
    *(uint16_t*)(area->next) = (uint16_t) tag;
#endif
    memcpy(area->next + 2, item, 4);
    area->next += 6;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_4_4(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 4 > 0
    *(uint32_t*)(area->next) = (uint32_t) tag;
#endif
    memcpy(area->next + 4, item, 4);
    area->next += 8;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 55


// Conveyor push methods

#line 60
static int
vector_push_0_4(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_0_4
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 60
static int
vector_push_4_4(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_4_4
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 71

#line 73
static int
matrix_push_1_4(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_1_4
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 73
static int
matrix_push_4_4(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_4_4
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 84

static int
tensor_push_4_4(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* tensor = (tensor_t*) self;
  route_t _route = tensor_route(tensor, pe);
  bool ok = porter_push_4_4
    (tensor->porters[0], _route.tag, item, _route.next);
  tensor->stats[convey_PUSHES] += ok;
  return ok;
}


// Conveyor pull methods

#line 100
#line 101

static int
vector_pull_0_4(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[1 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[1 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 4;
  if (from) {
    uint32_t source = buffer->source;
#if 1 == 1
    *from = source;
#else
    uint32_t tag = (0 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 1, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 0, 4);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_1_4(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 5;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (1 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 1, 4);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_4_4(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 8;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 4);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
tensor_pull_4_4(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[3 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[3 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 8;
  if (from) {
    uint32_t source = buffer->source;
#if 3 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 3, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 4);
  return convey_OK;
}

#line 137
#line 138


// Specialized pivot functions
#line 1 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/pivot.h"
// Copyright (c) 2020, Institute for Defense Analyses
// 4850 Mark Center Drive, Alexandria, VA 22311-1882; 703-845-2500
//
// All rights reserved.
//
// This file is part of the conveyor package. For license information,
// see the LICENSE file in the top level directory of the distribution.


// This file is designed to be "encased" by cases.pl.  The token 4
// must be #defcased to a number: either a positive item size or zero.

#if 4 == 0
#define porter_push_1_0 porter_push
#define porter_push_2_0 porter_push
#define porter_push_4_0 porter_push
#endif

#line 20
static bool
pivot_mid_1_4(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (4 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 1 * (1 + (4 + 1 - 1) / 1);
#else
    : 4 * (1 + (4 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint8_t*)packet;
    bool ok = porter_push_4_4
      (matrix->porters[1], source, packet + 1, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_1_4
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 20
static bool
pivot_mid_4_4(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (4 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 4 * (1 + (4 + 4 - 1) / 4);
#else
    : 4 * (1 + (4 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_4
      (matrix->porters[1], source, packet + 4, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_4
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 57

#line 59
static bool
pivot_early_1_4(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 1==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((1 == 1) ? 4 : 8);
  const size_t packet_bytes = (4 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (4 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_1_4
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_2_4(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 2==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((2 == 1) ? 4 : 8);
  const size_t packet_bytes = (4 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (4 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_2_4
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_4_4(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 4==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((4 == 1) ? 4 : 8);
  const size_t packet_bytes = (4 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (4 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_4_4
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 87

#line 89
static bool
pivot_late_1_4(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (4 == 0) ?
    porter_stride(tensor->porters[1]) : 1 * (1 + (4 + 1 - 1) / 1);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint8_t*)packet;
    int dest = tag & ((1 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((1 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_4
      (tensor->porters[2], tag, packet + 1, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_2_4(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (4 == 0) ?
    porter_stride(tensor->porters[1]) : 2 * (1 + (4 + 2 - 1) / 2);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint16_t*)packet;
    int dest = tag & ((2 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((2 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_4
      (tensor->porters[2], tag, packet + 2, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_4_4(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (4 == 0) ?
    porter_stride(tensor->porters[1]) : 4 * (1 + (4 + 4 - 1) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag & ((4 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((4 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_4
      (tensor->porters[2], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 117
#line 142 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/accel.c"

#line 27

#line 29
#line 30

static inline bool
porter_push_0_8(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 0 > 0
    *(void*)(area->next) = (void) tag;
#endif
    memcpy(area->next + 0, item, 8);
    area->next += 8;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_1_8(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 1 > 0
    *(uint8_t*)(area->next) = (uint8_t) tag;
#endif
    memcpy(area->next + 1, item, 8);
    area->next += 9;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_2_8(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 2 > 0
    *(uint16_t*)(area->next) = (uint16_t) tag;
#endif
    memcpy(area->next + 2, item, 8);
    area->next += 10;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_4_8(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 4 > 0
    *(uint32_t*)(area->next) = (uint32_t) tag;
#endif
    memcpy(area->next + 4, item, 8);
    area->next += 12;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 55


// Conveyor push methods

#line 60
static int
vector_push_0_8(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_0_8
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 60
static int
vector_push_4_8(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_4_8
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 71

#line 73
static int
matrix_push_1_8(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_1_8
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 73
static int
matrix_push_4_8(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_4_8
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 84

static int
tensor_push_4_8(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* tensor = (tensor_t*) self;
  route_t _route = tensor_route(tensor, pe);
  bool ok = porter_push_4_8
    (tensor->porters[0], _route.tag, item, _route.next);
  tensor->stats[convey_PUSHES] += ok;
  return ok;
}


// Conveyor pull methods

#line 100
#line 101

static int
vector_pull_0_8(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[1 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[1 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 8;
  if (from) {
    uint32_t source = buffer->source;
#if 1 == 1
    *from = source;
#else
    uint32_t tag = (0 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 1, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 0, 8);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_1_8(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 9;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (1 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 1, 8);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_4_8(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 12;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 8);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
tensor_pull_4_8(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[3 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[3 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 12;
  if (from) {
    uint32_t source = buffer->source;
#if 3 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 3, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 8);
  return convey_OK;
}

#line 137
#line 138


// Specialized pivot functions
#line 1 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/pivot.h"
// Copyright (c) 2020, Institute for Defense Analyses
// 4850 Mark Center Drive, Alexandria, VA 22311-1882; 703-845-2500
//
// All rights reserved.
//
// This file is part of the conveyor package. For license information,
// see the LICENSE file in the top level directory of the distribution.


// This file is designed to be "encased" by cases.pl.  The token 8
// must be #defcased to a number: either a positive item size or zero.

#if 8 == 0
#define porter_push_1_0 porter_push
#define porter_push_2_0 porter_push
#define porter_push_4_0 porter_push
#endif

#line 20
static bool
pivot_mid_1_8(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (8 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 1 * (1 + (8 + 1 - 1) / 1);
#else
    : 4 * (1 + (8 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint8_t*)packet;
    bool ok = porter_push_4_8
      (matrix->porters[1], source, packet + 1, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_1_8
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 20
static bool
pivot_mid_4_8(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (8 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 4 * (1 + (8 + 4 - 1) / 4);
#else
    : 4 * (1 + (8 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_8
      (matrix->porters[1], source, packet + 4, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_8
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 57

#line 59
static bool
pivot_early_1_8(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 1==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((1 == 1) ? 4 : 8);
  const size_t packet_bytes = (8 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (8 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_1_8
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_2_8(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 2==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((2 == 1) ? 4 : 8);
  const size_t packet_bytes = (8 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (8 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_2_8
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_4_8(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 4==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((4 == 1) ? 4 : 8);
  const size_t packet_bytes = (8 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (8 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_4_8
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 87

#line 89
static bool
pivot_late_1_8(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (8 == 0) ?
    porter_stride(tensor->porters[1]) : 1 * (1 + (8 + 1 - 1) / 1);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint8_t*)packet;
    int dest = tag & ((1 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((1 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_8
      (tensor->porters[2], tag, packet + 1, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_2_8(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (8 == 0) ?
    porter_stride(tensor->porters[1]) : 2 * (1 + (8 + 2 - 1) / 2);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint16_t*)packet;
    int dest = tag & ((2 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((2 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_8
      (tensor->porters[2], tag, packet + 2, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_4_8(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (8 == 0) ?
    porter_stride(tensor->porters[1]) : 4 * (1 + (8 + 4 - 1) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag & ((4 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((4 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_8
      (tensor->porters[2], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 117
#line 142 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/accel.c"

#line 27

#line 29
#line 30

static inline bool
porter_push_0_12(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 0 > 0
    *(void*)(area->next) = (void) tag;
#endif
    memcpy(area->next + 0, item, 12);
    area->next += 12;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_1_12(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 1 > 0
    *(uint8_t*)(area->next) = (uint8_t) tag;
#endif
    memcpy(area->next + 1, item, 12);
    area->next += 13;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_2_12(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 2 > 0
    *(uint16_t*)(area->next) = (uint16_t) tag;
#endif
    memcpy(area->next + 2, item, 12);
    area->next += 14;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_4_12(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 4 > 0
    *(uint32_t*)(area->next) = (uint32_t) tag;
#endif
    memcpy(area->next + 4, item, 12);
    area->next += 16;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 55


// Conveyor push methods

#line 60
static int
vector_push_0_12(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_0_12
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 60
static int
vector_push_4_12(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_4_12
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 71

#line 73
static int
matrix_push_1_12(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_1_12
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 73
static int
matrix_push_4_12(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_4_12
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 84

static int
tensor_push_4_12(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* tensor = (tensor_t*) self;
  route_t _route = tensor_route(tensor, pe);
  bool ok = porter_push_4_12
    (tensor->porters[0], _route.tag, item, _route.next);
  tensor->stats[convey_PUSHES] += ok;
  return ok;
}


// Conveyor pull methods

#line 100
#line 101

static int
vector_pull_0_12(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[1 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[1 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 12;
  if (from) {
    uint32_t source = buffer->source;
#if 1 == 1
    *from = source;
#else
    uint32_t tag = (0 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 1, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 0, 12);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_1_12(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 13;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (1 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 1, 12);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_4_12(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 16;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 12);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
tensor_pull_4_12(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[3 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[3 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 16;
  if (from) {
    uint32_t source = buffer->source;
#if 3 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 3, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 12);
  return convey_OK;
}

#line 137
#line 138


// Specialized pivot functions
#line 1 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/pivot.h"
// Copyright (c) 2020, Institute for Defense Analyses
// 4850 Mark Center Drive, Alexandria, VA 22311-1882; 703-845-2500
//
// All rights reserved.
//
// This file is part of the conveyor package. For license information,
// see the LICENSE file in the top level directory of the distribution.


// This file is designed to be "encased" by cases.pl.  The token 12
// must be #defcased to a number: either a positive item size or zero.

#if 12 == 0
#define porter_push_1_0 porter_push
#define porter_push_2_0 porter_push
#define porter_push_4_0 porter_push
#endif

#line 20
static bool
pivot_mid_1_12(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (12 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 1 * (1 + (12 + 1 - 1) / 1);
#else
    : 4 * (1 + (12 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint8_t*)packet;
    bool ok = porter_push_4_12
      (matrix->porters[1], source, packet + 1, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_1_12
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 20
static bool
pivot_mid_4_12(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (12 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 4 * (1 + (12 + 4 - 1) / 4);
#else
    : 4 * (1 + (12 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_12
      (matrix->porters[1], source, packet + 4, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_12
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 57

#line 59
static bool
pivot_early_1_12(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 1==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((1 == 1) ? 4 : 8);
  const size_t packet_bytes = (12 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (12 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_1_12
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_2_12(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 2==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((2 == 1) ? 4 : 8);
  const size_t packet_bytes = (12 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (12 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_2_12
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_4_12(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 4==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((4 == 1) ? 4 : 8);
  const size_t packet_bytes = (12 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (12 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_4_12
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 87

#line 89
static bool
pivot_late_1_12(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (12 == 0) ?
    porter_stride(tensor->porters[1]) : 1 * (1 + (12 + 1 - 1) / 1);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint8_t*)packet;
    int dest = tag & ((1 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((1 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_12
      (tensor->porters[2], tag, packet + 1, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_2_12(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (12 == 0) ?
    porter_stride(tensor->porters[1]) : 2 * (1 + (12 + 2 - 1) / 2);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint16_t*)packet;
    int dest = tag & ((2 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((2 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_12
      (tensor->porters[2], tag, packet + 2, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_4_12(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (12 == 0) ?
    porter_stride(tensor->porters[1]) : 4 * (1 + (12 + 4 - 1) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag & ((4 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((4 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_12
      (tensor->porters[2], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 117
#line 142 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/accel.c"

#line 27

#line 29
#line 30

static inline bool
porter_push_0_16(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 0 > 0
    *(void*)(area->next) = (void) tag;
#endif
    memcpy(area->next + 0, item, 16);
    area->next += 16;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_1_16(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 1 > 0
    *(uint8_t*)(area->next) = (uint8_t) tag;
#endif
    memcpy(area->next + 1, item, 16);
    area->next += 17;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_2_16(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 2 > 0
    *(uint16_t*)(area->next) = (uint16_t) tag;
#endif
    memcpy(area->next + 2, item, 16);
    area->next += 18;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_4_16(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 4 > 0
    *(uint32_t*)(area->next) = (uint32_t) tag;
#endif
    memcpy(area->next + 4, item, 16);
    area->next += 20;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 55


// Conveyor push methods

#line 60
static int
vector_push_0_16(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_0_16
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 60
static int
vector_push_4_16(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_4_16
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 71

#line 73
static int
matrix_push_1_16(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_1_16
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 73
static int
matrix_push_4_16(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_4_16
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 84

static int
tensor_push_4_16(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* tensor = (tensor_t*) self;
  route_t _route = tensor_route(tensor, pe);
  bool ok = porter_push_4_16
    (tensor->porters[0], _route.tag, item, _route.next);
  tensor->stats[convey_PUSHES] += ok;
  return ok;
}


// Conveyor pull methods

#line 100
#line 101

static int
vector_pull_0_16(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[1 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[1 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 16;
  if (from) {
    uint32_t source = buffer->source;
#if 1 == 1
    *from = source;
#else
    uint32_t tag = (0 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 1, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 0, 16);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_1_16(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 17;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (1 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 1, 16);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_4_16(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 20;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 16);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
tensor_pull_4_16(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[3 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[3 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 20;
  if (from) {
    uint32_t source = buffer->source;
#if 3 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 3, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 16);
  return convey_OK;
}

#line 137
#line 138


// Specialized pivot functions
#line 1 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/pivot.h"
// Copyright (c) 2020, Institute for Defense Analyses
// 4850 Mark Center Drive, Alexandria, VA 22311-1882; 703-845-2500
//
// All rights reserved.
//
// This file is part of the conveyor package. For license information,
// see the LICENSE file in the top level directory of the distribution.


// This file is designed to be "encased" by cases.pl.  The token 16
// must be #defcased to a number: either a positive item size or zero.

#if 16 == 0
#define porter_push_1_0 porter_push
#define porter_push_2_0 porter_push
#define porter_push_4_0 porter_push
#endif

#line 20
static bool
pivot_mid_1_16(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (16 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 1 * (1 + (16 + 1 - 1) / 1);
#else
    : 4 * (1 + (16 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint8_t*)packet;
    bool ok = porter_push_4_16
      (matrix->porters[1], source, packet + 1, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_1_16
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 20
static bool
pivot_mid_4_16(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (16 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 4 * (1 + (16 + 4 - 1) / 4);
#else
    : 4 * (1 + (16 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_16
      (matrix->porters[1], source, packet + 4, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_16
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 57

#line 59
static bool
pivot_early_1_16(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 1==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((1 == 1) ? 4 : 8);
  const size_t packet_bytes = (16 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (16 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_1_16
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_2_16(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 2==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((2 == 1) ? 4 : 8);
  const size_t packet_bytes = (16 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (16 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_2_16
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_4_16(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 4==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((4 == 1) ? 4 : 8);
  const size_t packet_bytes = (16 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (16 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_4_16
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 87

#line 89
static bool
pivot_late_1_16(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (16 == 0) ?
    porter_stride(tensor->porters[1]) : 1 * (1 + (16 + 1 - 1) / 1);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint8_t*)packet;
    int dest = tag & ((1 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((1 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_16
      (tensor->porters[2], tag, packet + 1, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_2_16(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (16 == 0) ?
    porter_stride(tensor->porters[1]) : 2 * (1 + (16 + 2 - 1) / 2);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint16_t*)packet;
    int dest = tag & ((2 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((2 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_16
      (tensor->porters[2], tag, packet + 2, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_4_16(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (16 == 0) ?
    porter_stride(tensor->porters[1]) : 4 * (1 + (16 + 4 - 1) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag & ((4 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((4 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_16
      (tensor->porters[2], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 117
#line 142 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/accel.c"

#line 27

#line 29
#line 30

static inline bool
porter_push_0_20(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 0 > 0
    *(void*)(area->next) = (void) tag;
#endif
    memcpy(area->next + 0, item, 20);
    area->next += 20;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_1_20(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 1 > 0
    *(uint8_t*)(area->next) = (uint8_t) tag;
#endif
    memcpy(area->next + 1, item, 20);
    area->next += 21;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_2_20(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 2 > 0
    *(uint16_t*)(area->next) = (uint16_t) tag;
#endif
    memcpy(area->next + 2, item, 20);
    area->next += 22;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_4_20(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 4 > 0
    *(uint32_t*)(area->next) = (uint32_t) tag;
#endif
    memcpy(area->next + 4, item, 20);
    area->next += 24;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 55


// Conveyor push methods

#line 60
static int
vector_push_0_20(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_0_20
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 60
static int
vector_push_4_20(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_4_20
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 71

#line 73
static int
matrix_push_1_20(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_1_20
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 73
static int
matrix_push_4_20(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_4_20
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 84

static int
tensor_push_4_20(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* tensor = (tensor_t*) self;
  route_t _route = tensor_route(tensor, pe);
  bool ok = porter_push_4_20
    (tensor->porters[0], _route.tag, item, _route.next);
  tensor->stats[convey_PUSHES] += ok;
  return ok;
}


// Conveyor pull methods

#line 100
#line 101

static int
vector_pull_0_20(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[1 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[1 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 20;
  if (from) {
    uint32_t source = buffer->source;
#if 1 == 1
    *from = source;
#else
    uint32_t tag = (0 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 1, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 0, 20);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_1_20(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 21;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (1 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 1, 20);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_4_20(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 24;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 20);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
tensor_pull_4_20(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[3 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[3 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 24;
  if (from) {
    uint32_t source = buffer->source;
#if 3 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 3, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 20);
  return convey_OK;
}

#line 137
#line 138


// Specialized pivot functions
#line 1 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/pivot.h"
// Copyright (c) 2020, Institute for Defense Analyses
// 4850 Mark Center Drive, Alexandria, VA 22311-1882; 703-845-2500
//
// All rights reserved.
//
// This file is part of the conveyor package. For license information,
// see the LICENSE file in the top level directory of the distribution.


// This file is designed to be "encased" by cases.pl.  The token 20
// must be #defcased to a number: either a positive item size or zero.

#if 20 == 0
#define porter_push_1_0 porter_push
#define porter_push_2_0 porter_push
#define porter_push_4_0 porter_push
#endif

#line 20
static bool
pivot_mid_1_20(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (20 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 1 * (1 + (20 + 1 - 1) / 1);
#else
    : 4 * (1 + (20 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint8_t*)packet;
    bool ok = porter_push_4_20
      (matrix->porters[1], source, packet + 1, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_1_20
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 20
static bool
pivot_mid_4_20(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (20 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 4 * (1 + (20 + 4 - 1) / 4);
#else
    : 4 * (1 + (20 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_20
      (matrix->porters[1], source, packet + 4, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_20
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 57

#line 59
static bool
pivot_early_1_20(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 1==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((1 == 1) ? 4 : 8);
  const size_t packet_bytes = (20 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (20 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_1_20
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_2_20(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 2==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((2 == 1) ? 4 : 8);
  const size_t packet_bytes = (20 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (20 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_2_20
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_4_20(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 4==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((4 == 1) ? 4 : 8);
  const size_t packet_bytes = (20 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (20 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_4_20
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 87

#line 89
static bool
pivot_late_1_20(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (20 == 0) ?
    porter_stride(tensor->porters[1]) : 1 * (1 + (20 + 1 - 1) / 1);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint8_t*)packet;
    int dest = tag & ((1 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((1 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_20
      (tensor->porters[2], tag, packet + 1, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_2_20(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (20 == 0) ?
    porter_stride(tensor->porters[1]) : 2 * (1 + (20 + 2 - 1) / 2);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint16_t*)packet;
    int dest = tag & ((2 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((2 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_20
      (tensor->porters[2], tag, packet + 2, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_4_20(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (20 == 0) ?
    porter_stride(tensor->porters[1]) : 4 * (1 + (20 + 4 - 1) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag & ((4 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((4 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_20
      (tensor->porters[2], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 117
#line 142 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/accel.c"

#line 27

#line 29
#line 30

static inline bool
porter_push_0_24(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 0 > 0
    *(void*)(area->next) = (void) tag;
#endif
    memcpy(area->next + 0, item, 24);
    area->next += 24;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_1_24(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 1 > 0
    *(uint8_t*)(area->next) = (uint8_t) tag;
#endif
    memcpy(area->next + 1, item, 24);
    area->next += 25;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_2_24(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 2 > 0
    *(uint16_t*)(area->next) = (uint16_t) tag;
#endif
    memcpy(area->next + 2, item, 24);
    area->next += 26;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_4_24(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 4 > 0
    *(uint32_t*)(area->next) = (uint32_t) tag;
#endif
    memcpy(area->next + 4, item, 24);
    area->next += 28;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 55


// Conveyor push methods

#line 60
static int
vector_push_0_24(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_0_24
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 60
static int
vector_push_4_24(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_4_24
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 71

#line 73
static int
matrix_push_1_24(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_1_24
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 73
static int
matrix_push_4_24(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_4_24
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 84

static int
tensor_push_4_24(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* tensor = (tensor_t*) self;
  route_t _route = tensor_route(tensor, pe);
  bool ok = porter_push_4_24
    (tensor->porters[0], _route.tag, item, _route.next);
  tensor->stats[convey_PUSHES] += ok;
  return ok;
}


// Conveyor pull methods

#line 100
#line 101

static int
vector_pull_0_24(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[1 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[1 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 24;
  if (from) {
    uint32_t source = buffer->source;
#if 1 == 1
    *from = source;
#else
    uint32_t tag = (0 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 1, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 0, 24);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_1_24(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 25;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (1 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 1, 24);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_4_24(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 28;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 24);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
tensor_pull_4_24(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[3 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[3 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 28;
  if (from) {
    uint32_t source = buffer->source;
#if 3 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 3, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 24);
  return convey_OK;
}

#line 137
#line 138


// Specialized pivot functions
#line 1 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/pivot.h"
// Copyright (c) 2020, Institute for Defense Analyses
// 4850 Mark Center Drive, Alexandria, VA 22311-1882; 703-845-2500
//
// All rights reserved.
//
// This file is part of the conveyor package. For license information,
// see the LICENSE file in the top level directory of the distribution.


// This file is designed to be "encased" by cases.pl.  The token 24
// must be #defcased to a number: either a positive item size or zero.

#if 24 == 0
#define porter_push_1_0 porter_push
#define porter_push_2_0 porter_push
#define porter_push_4_0 porter_push
#endif

#line 20
static bool
pivot_mid_1_24(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (24 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 1 * (1 + (24 + 1 - 1) / 1);
#else
    : 4 * (1 + (24 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint8_t*)packet;
    bool ok = porter_push_4_24
      (matrix->porters[1], source, packet + 1, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_1_24
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 20
static bool
pivot_mid_4_24(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (24 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 4 * (1 + (24 + 4 - 1) / 4);
#else
    : 4 * (1 + (24 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_24
      (matrix->porters[1], source, packet + 4, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_24
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 57

#line 59
static bool
pivot_early_1_24(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 1==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((1 == 1) ? 4 : 8);
  const size_t packet_bytes = (24 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (24 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_1_24
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_2_24(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 2==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((2 == 1) ? 4 : 8);
  const size_t packet_bytes = (24 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (24 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_2_24
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_4_24(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 4==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((4 == 1) ? 4 : 8);
  const size_t packet_bytes = (24 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (24 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_4_24
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 87

#line 89
static bool
pivot_late_1_24(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (24 == 0) ?
    porter_stride(tensor->porters[1]) : 1 * (1 + (24 + 1 - 1) / 1);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint8_t*)packet;
    int dest = tag & ((1 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((1 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_24
      (tensor->porters[2], tag, packet + 1, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_2_24(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (24 == 0) ?
    porter_stride(tensor->porters[1]) : 2 * (1 + (24 + 2 - 1) / 2);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint16_t*)packet;
    int dest = tag & ((2 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((2 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_24
      (tensor->porters[2], tag, packet + 2, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_4_24(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (24 == 0) ?
    porter_stride(tensor->porters[1]) : 4 * (1 + (24 + 4 - 1) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag & ((4 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((4 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_24
      (tensor->porters[2], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 117
#line 142 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/accel.c"

#line 27

#line 29
#line 30

static inline bool
porter_push_0_28(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 0 > 0
    *(void*)(area->next) = (void) tag;
#endif
    memcpy(area->next + 0, item, 28);
    area->next += 28;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_1_28(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 1 > 0
    *(uint8_t*)(area->next) = (uint8_t) tag;
#endif
    memcpy(area->next + 1, item, 28);
    area->next += 29;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_2_28(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 2 > 0
    *(uint16_t*)(area->next) = (uint16_t) tag;
#endif
    memcpy(area->next + 2, item, 28);
    area->next += 30;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_4_28(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 4 > 0
    *(uint32_t*)(area->next) = (uint32_t) tag;
#endif
    memcpy(area->next + 4, item, 28);
    area->next += 32;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 55


// Conveyor push methods

#line 60
static int
vector_push_0_28(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_0_28
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 60
static int
vector_push_4_28(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_4_28
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 71

#line 73
static int
matrix_push_1_28(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_1_28
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 73
static int
matrix_push_4_28(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_4_28
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 84

static int
tensor_push_4_28(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* tensor = (tensor_t*) self;
  route_t _route = tensor_route(tensor, pe);
  bool ok = porter_push_4_28
    (tensor->porters[0], _route.tag, item, _route.next);
  tensor->stats[convey_PUSHES] += ok;
  return ok;
}


// Conveyor pull methods

#line 100
#line 101

static int
vector_pull_0_28(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[1 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[1 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 28;
  if (from) {
    uint32_t source = buffer->source;
#if 1 == 1
    *from = source;
#else
    uint32_t tag = (0 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 1, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 0, 28);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_1_28(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 29;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (1 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 1, 28);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_4_28(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 32;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 28);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
tensor_pull_4_28(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[3 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[3 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 32;
  if (from) {
    uint32_t source = buffer->source;
#if 3 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 3, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 28);
  return convey_OK;
}

#line 137
#line 138


// Specialized pivot functions
#line 1 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/pivot.h"
// Copyright (c) 2020, Institute for Defense Analyses
// 4850 Mark Center Drive, Alexandria, VA 22311-1882; 703-845-2500
//
// All rights reserved.
//
// This file is part of the conveyor package. For license information,
// see the LICENSE file in the top level directory of the distribution.


// This file is designed to be "encased" by cases.pl.  The token 28
// must be #defcased to a number: either a positive item size or zero.

#if 28 == 0
#define porter_push_1_0 porter_push
#define porter_push_2_0 porter_push
#define porter_push_4_0 porter_push
#endif

#line 20
static bool
pivot_mid_1_28(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (28 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 1 * (1 + (28 + 1 - 1) / 1);
#else
    : 4 * (1 + (28 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint8_t*)packet;
    bool ok = porter_push_4_28
      (matrix->porters[1], source, packet + 1, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_1_28
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 20
static bool
pivot_mid_4_28(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (28 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 4 * (1 + (28 + 4 - 1) / 4);
#else
    : 4 * (1 + (28 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_28
      (matrix->porters[1], source, packet + 4, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_28
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 57

#line 59
static bool
pivot_early_1_28(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 1==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((1 == 1) ? 4 : 8);
  const size_t packet_bytes = (28 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (28 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_1_28
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_2_28(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 2==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((2 == 1) ? 4 : 8);
  const size_t packet_bytes = (28 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (28 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_2_28
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_4_28(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 4==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((4 == 1) ? 4 : 8);
  const size_t packet_bytes = (28 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (28 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_4_28
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 87

#line 89
static bool
pivot_late_1_28(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (28 == 0) ?
    porter_stride(tensor->porters[1]) : 1 * (1 + (28 + 1 - 1) / 1);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint8_t*)packet;
    int dest = tag & ((1 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((1 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_28
      (tensor->porters[2], tag, packet + 1, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_2_28(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (28 == 0) ?
    porter_stride(tensor->porters[1]) : 2 * (1 + (28 + 2 - 1) / 2);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint16_t*)packet;
    int dest = tag & ((2 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((2 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_28
      (tensor->porters[2], tag, packet + 2, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_4_28(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (28 == 0) ?
    porter_stride(tensor->porters[1]) : 4 * (1 + (28 + 4 - 1) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag & ((4 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((4 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_28
      (tensor->porters[2], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 117
#line 142 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/accel.c"

#line 27

#line 29
#line 30

static inline bool
porter_push_0_32(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 0 > 0
    *(void*)(area->next) = (void) tag;
#endif
    memcpy(area->next + 0, item, 32);
    area->next += 32;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_1_32(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 1 > 0
    *(uint8_t*)(area->next) = (uint8_t) tag;
#endif
    memcpy(area->next + 1, item, 32);
    area->next += 33;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_2_32(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 2 > 0
    *(uint16_t*)(area->next) = (uint16_t) tag;
#endif
    memcpy(area->next + 2, item, 32);
    area->next += 34;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 29
#line 30

static inline bool
porter_push_4_32(porter_t* self, uint64_t tag, const void* item, int dest)
{
  area_t* area = &self->send_areas[dest];
  bool room = (area->next < area->limit);
  if (room) {
    _prefetch_x(area->next + 96);
#if 4 > 0
    *(uint32_t*)(area->next) = (uint32_t) tag;
#endif
    memcpy(area->next + 4, item, 32);
    area->next += 36;
    if (area->next >= area->limit) {
      porter_close_buffer(self, dest, area);
      porter_try_send(self, dest);
    }
  }
  else
    porter_try_send(self, dest);
  return room;
}

#line 54
#line 55


// Conveyor push methods

#line 60
static int
vector_push_0_32(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_0_32
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 60
static int
vector_push_4_32(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* vector = (tensor_t*) self;
  route_t _route = vector_route(vector, pe);
  bool ok = porter_push_4_32
    (vector->porters[0], _route.tag, item, _route.next);
  vector->stats[convey_PUSHES] += ok;
  return ok;
}
#line 71

#line 73
static int
matrix_push_1_32(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_1_32
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 73
static int
matrix_push_4_32(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* matrix = (tensor_t*) self;
  route_t _route = matrix_route(matrix, pe);
  bool ok = porter_push_4_32
    (matrix->porters[0], _route.tag, item, _route.next);
  matrix->stats[convey_PUSHES] += ok;
  return ok;
}
#line 84

static int
tensor_push_4_32(convey_t* self, const void* item, int64_t pe)
{
  tensor_t* tensor = (tensor_t*) self;
  route_t _route = tensor_route(tensor, pe);
  bool ok = porter_push_4_32
    (tensor->porters[0], _route.tag, item, _route.next);
  tensor->stats[convey_PUSHES] += ok;
  return ok;
}


// Conveyor pull methods

#line 100
#line 101

static int
vector_pull_0_32(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[1 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[1 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 32;
  if (from) {
    uint32_t source = buffer->source;
#if 1 == 1
    *from = source;
#else
    uint32_t tag = (0 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 1, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 0, 32);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_1_32(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 33;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (1 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 1, 32);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
matrix_pull_4_32(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[2 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[2 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 36;
  if (from) {
    uint32_t source = buffer->source;
#if 2 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 2, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 32);
  return convey_OK;
}

#line 137
#line 100
#line 101

static int
tensor_pull_4_32(convey_t* self, void* item, int64_t* from)
{
  tensor_t* tensor = (tensor_t*) self;
  buffer_t* buffer = tensor->buffer;

  if (buffer && buffer->start == buffer->limit) {
    porter_return(tensor->porters[3 - 1]);
    buffer = NULL;
  }
  if (!buffer) {
    buffer = porter_borrow(tensor->porters[3 - 1]);
    tensor->buffer = buffer;
    if (!buffer)
      return convey_FAIL;
  }

  char* packet = &buffer->data[buffer->start];
  buffer->start += 36;
  if (from) {
    uint32_t source = buffer->source;
#if 3 == 1
    *from = source;
#else
    uint32_t tag = (4 == 1) ? *(uint8_t*)packet : *(uint32_t*)packet;
    *from = origin_from_tag(tensor, 3, tag, source);
#endif
  }

  tensor->stats[convey_PULLS]++;
  memcpy(item, packet + 4, 32);
  return convey_OK;
}

#line 137
#line 138


// Specialized pivot functions
#line 1 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/pivot.h"
// Copyright (c) 2020, Institute for Defense Analyses
// 4850 Mark Center Drive, Alexandria, VA 22311-1882; 703-845-2500
//
// All rights reserved.
//
// This file is part of the conveyor package. For license information,
// see the LICENSE file in the top level directory of the distribution.


// This file is designed to be "encased" by cases.pl.  The token 32
// must be #defcased to a number: either a positive item size or zero.

#if 32 == 0
#define porter_push_1_0 porter_push
#define porter_push_2_0 porter_push
#define porter_push_4_0 porter_push
#endif

#line 20
static bool
pivot_mid_1_32(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (32 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 1 * (1 + (32 + 1 - 1) / 1);
#else
    : 4 * (1 + (32 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint8_t*)packet;
    bool ok = porter_push_4_32
      (matrix->porters[1], source, packet + 1, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_1_32
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 20
static bool
pivot_mid_4_32(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (32 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 4 * (1 + (32 + 4 - 1) / 4);
#else
    : 4 * (1 + (32 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_32
      (matrix->porters[1], source, packet + 4, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_32
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 57

#line 59
static bool
pivot_early_1_32(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 1==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((1 == 1) ? 4 : 8);
  const size_t packet_bytes = (32 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (32 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_1_32
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_2_32(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 2==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((2 == 1) ? 4 : 8);
  const size_t packet_bytes = (32 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (32 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_2_32
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_4_32(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 4==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((4 == 1) ? 4 : 8);
  const size_t packet_bytes = (32 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (32 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_4_32
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 87

#line 89
static bool
pivot_late_1_32(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (32 == 0) ?
    porter_stride(tensor->porters[1]) : 1 * (1 + (32 + 1 - 1) / 1);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint8_t*)packet;
    int dest = tag & ((1 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((1 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_32
      (tensor->porters[2], tag, packet + 1, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_2_32(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (32 == 0) ?
    porter_stride(tensor->porters[1]) : 2 * (1 + (32 + 2 - 1) / 2);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint16_t*)packet;
    int dest = tag & ((2 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((2 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_32
      (tensor->porters[2], tag, packet + 2, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_4_32(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (32 == 0) ?
    porter_stride(tensor->porters[1]) : 4 * (1 + (32 + 4 - 1) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag & ((4 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((4 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_32
      (tensor->porters[2], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 117
#line 142 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/accel.c"

#line 144


// Standard pivot functions
#line 148
#line 1 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/pivot.h"
// Copyright (c) 2020, Institute for Defense Analyses
// 4850 Mark Center Drive, Alexandria, VA 22311-1882; 703-845-2500
//
// All rights reserved.
//
// This file is part of the conveyor package. For license information,
// see the LICENSE file in the top level directory of the distribution.


// This file is designed to be "encased" by cases.pl.  The token 0
// must be #defcased to a number: either a positive item size or zero.

#if 0 == 0
#define porter_push_1_0 porter_push
#define porter_push_2_0 porter_push
#define porter_push_4_0 porter_push
#endif

#line 20
static bool
pivot_mid_1_0(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (0 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 1 * (1 + (0 + 1 - 1) / 1);
#else
    : 4 * (1 + (0 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint8_t*)packet;
    bool ok = porter_push_4_0
      (matrix->porters[1], source, packet + 1, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_1_0
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 20
static bool
pivot_mid_4_0(tensor_t* matrix, buffer_t* buffer)
{
  // tag is (y'); we are (x',y); source is x, tag becomes (x)
  ACT_START(matrix_pivot);
  const uint64_t source = buffer->source;
  const size_t packet_bytes = (0 == 0) ? porter_stride(matrix->porters[0])
#if MATRIX_REMOTE_HOP == 0
    : 4 * (1 + (0 + 4 - 1) / 4);
#else
    : 4 * (1 + (0 + 3) / 4);
#endif

  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
#if MATRIX_REMOTE_HOP == 0
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_0
      (matrix->porters[1], source, packet + 4, dest);
#else
    int dest = *(uint32_t*)packet;
    bool ok = porter_push_4_0
      (matrix->porters[1], source, packet + 4, dest);
#endif
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(matrix_pivot);
      return false;
    }
  }

  buffer->start = buffer->limit;
  ACT_STOP(matrix_pivot);
  return true;
}
#line 57

#line 59
static bool
pivot_early_1_0(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 1==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((1 == 1) ? 4 : 8);
  const size_t packet_bytes = (0 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (0 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_1_0
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_2_0(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 2==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((2 == 1) ? 4 : 8);
  const size_t packet_bytes = (0 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (0 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_2_0
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 59
static bool
pivot_early_4_0(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (x',z'); source is z; we are (x,y,y')
  // hop to (x',y,y'), tag becomes (z, z') [4 bits + 4 bits if 4==1]
  ACT_START(tensor_early);
  const uint32_t source = buffer->source << ((4 == 1) ? 4 : 8);
  const size_t packet_bytes = (0 == 0) ?
    porter_stride(tensor->porters[0]) : 4 * (1 + (0 + 3) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag >> 8;
    tag = (tag & 0xFF) | source;
    bool ok = porter_push_4_0
      (tensor->porters[1], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_early);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_early);
  return true;
}
#line 87

#line 89
static bool
pivot_late_1_0(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (0 == 0) ?
    porter_stride(tensor->porters[1]) : 1 * (1 + (0 + 1 - 1) / 1);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint8_t*)packet;
    int dest = tag & ((1 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((1 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_0
      (tensor->porters[2], tag, packet + 1, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_2_0(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (0 == 0) ?
    porter_stride(tensor->porters[1]) : 2 * (1 + (0 + 2 - 1) / 2);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint16_t*)packet;
    int dest = tag & ((2 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((2 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_0
      (tensor->porters[2], tag, packet + 2, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 89
static bool
pivot_late_4_0(tensor_t* tensor, buffer_t* buffer)
{
  // tag is (z,z'), source is x, we are (x',y',y)
  // hop to (x',y',z'), tag becomes (x,z)
  ACT_START(tensor_late);
  const uint32_t source = buffer->source << 8;
  const size_t packet_bytes = (0 == 0) ?
    porter_stride(tensor->porters[1]) : 4 * (1 + (0 + 4 - 1) / 4);
  char* packet = buffer->data + buffer->start;
  char* limit = buffer->data + buffer->limit;
  for (; packet < limit; packet += packet_bytes) {
    uint32_t tag = *(uint32_t*)packet;
    int dest = tag & ((4 == 1) ? 0xF : 0xFF);
    tag = (tag >> ((4 == 1) ? 4 : 8)) | source;
    bool ok = porter_push_4_0
      (tensor->porters[2], tag, packet + 4, dest);
    if (!ok) {
      buffer->start = packet - buffer->data;
      ACT_STOP(tensor_late);
      return false;
    }
  }
  buffer->start = buffer->limit;
  ACT_STOP(tensor_late);
  return true;
}
#line 117
#line 149 "/storage/coda1/p-vsarkar9/1/ssinghal74/conveyors2.0/bale/src/bale_classic/convey/accel.c"
#line 150


/*** Selector Functions ***/

static push_f* const push_functions[][5] = {
#line 156
  { &vector_push_0_4, &vector_push_4_4,
      &matrix_push_1_4, &matrix_push_4_4, 
      &tensor_push_4_4 },
#line 156
  { &vector_push_0_8, &vector_push_4_8,
      &matrix_push_1_8, &matrix_push_4_8, 
      &tensor_push_4_8 },
#line 156
  { &vector_push_0_12, &vector_push_4_12,
      &matrix_push_1_12, &matrix_push_4_12, 
      &tensor_push_4_12 },
#line 156
  { &vector_push_0_16, &vector_push_4_16,
      &matrix_push_1_16, &matrix_push_4_16, 
      &tensor_push_4_16 },
#line 156
  { &vector_push_0_20, &vector_push_4_20,
      &matrix_push_1_20, &matrix_push_4_20, 
      &tensor_push_4_20 },
#line 156
  { &vector_push_0_24, &vector_push_4_24,
      &matrix_push_1_24, &matrix_push_4_24, 
      &tensor_push_4_24 },
#line 156
  { &vector_push_0_28, &vector_push_4_28,
      &matrix_push_1_28, &matrix_push_4_28, 
      &tensor_push_4_28 },
#line 156
  { &vector_push_0_32, &vector_push_4_32,
      &matrix_push_1_32, &matrix_push_4_32, 
      &tensor_push_4_32 },
#line 160
};

static pull_f* const pull_functions[][4] = {
#line 164
  { &vector_pull_0_4, &matrix_pull_4_4, &tensor_pull_4_4,
    &matrix_pull_1_4 },
#line 164
  { &vector_pull_0_8, &matrix_pull_4_8, &tensor_pull_4_8,
    &matrix_pull_1_8 },
#line 164
  { &vector_pull_0_12, &matrix_pull_4_12, &tensor_pull_4_12,
    &matrix_pull_1_12 },
#line 164
  { &vector_pull_0_16, &matrix_pull_4_16, &tensor_pull_4_16,
    &matrix_pull_1_16 },
#line 164
  { &vector_pull_0_20, &matrix_pull_4_20, &tensor_pull_4_20,
    &matrix_pull_1_20 },
#line 164
  { &vector_pull_0_24, &matrix_pull_4_24, &tensor_pull_4_24,
    &matrix_pull_1_24 },
#line 164
  { &vector_pull_0_28, &matrix_pull_4_28, &tensor_pull_4_28,
    &matrix_pull_1_28 },
#line 164
  { &vector_pull_0_32, &matrix_pull_4_32, &tensor_pull_4_32,
    &matrix_pull_1_32 },
#line 167
};

static pivot_f* const pivot_functions[][8] = {
#line 171
  { &pivot_mid_1_4, &pivot_mid_4_4,
    &pivot_early_1_4, &pivot_early_2_4, &pivot_early_4_4,
    &pivot_late_1_4, &pivot_late_2_4, &pivot_late_4_4 },
#line 171
  { &pivot_mid_1_8, &pivot_mid_4_8,
    &pivot_early_1_8, &pivot_early_2_8, &pivot_early_4_8,
    &pivot_late_1_8, &pivot_late_2_8, &pivot_late_4_8 },
#line 171
  { &pivot_mid_1_12, &pivot_mid_4_12,
    &pivot_early_1_12, &pivot_early_2_12, &pivot_early_4_12,
    &pivot_late_1_12, &pivot_late_2_12, &pivot_late_4_12 },
#line 171
  { &pivot_mid_1_16, &pivot_mid_4_16,
    &pivot_early_1_16, &pivot_early_2_16, &pivot_early_4_16,
    &pivot_late_1_16, &pivot_late_2_16, &pivot_late_4_16 },
#line 171
  { &pivot_mid_1_20, &pivot_mid_4_20,
    &pivot_early_1_20, &pivot_early_2_20, &pivot_early_4_20,
    &pivot_late_1_20, &pivot_late_2_20, &pivot_late_4_20 },
#line 171
  { &pivot_mid_1_24, &pivot_mid_4_24,
    &pivot_early_1_24, &pivot_early_2_24, &pivot_early_4_24,
    &pivot_late_1_24, &pivot_late_2_24, &pivot_late_4_24 },
#line 171
  { &pivot_mid_1_28, &pivot_mid_4_28,
    &pivot_early_1_28, &pivot_early_2_28, &pivot_early_4_28,
    &pivot_late_1_28, &pivot_late_2_28, &pivot_late_4_28 },
#line 171
  { &pivot_mid_1_32, &pivot_mid_4_32,
    &pivot_early_1_32, &pivot_early_2_32, &pivot_early_4_32,
    &pivot_late_1_32, &pivot_late_2_32, &pivot_late_4_32 },
#line 175
};

static int
item_index(size_t item_bytes)
{
  if (item_bytes > 32 || (item_bytes & 3))
    return -1;
  return (item_bytes / 4) - 1;
}

push_f*
tensor_select_push(int order, size_t tag_bytes, size_t item_bytes)
{
  int index = item_index(item_bytes);
  if (index < 0)
    return NULL;
  if (order == 1 && tag_bytes == 0)
    return push_functions[index][0];
  if (order == 1 && tag_bytes == 4)
    return push_functions[index][1];
  if (order == 2 && tag_bytes == 1)
    return push_functions[index][2];
  if (order == 2 && tag_bytes == 4)
    return push_functions[index][3];
  if (order == 3 && tag_bytes == 4)
    return push_functions[index][4];
  return NULL;
}

pull_f*
tensor_select_pull(int order, size_t tag_bytes, size_t item_bytes)
{
  int index = item_index(item_bytes);
  if (index < 0)
    return NULL;
#if MATRIX_REMOTE_HOP == 1
  if (order == 2 && tag_bytes == 1)
    return pull_functions[index][3];
#endif
  if (tag_bytes != ((order == 1) ? 0 : 4))
    return NULL;
  return pull_functions[index][order - 1];
}

pivot_f*
tensor_select_pivot_mid(size_t tag_bytes, size_t item_bytes)
{
  int index = item_index(item_bytes);
  if (tag_bytes != 1 && tag_bytes != 4)
    return NULL;
  if (index < 0)
    return (tag_bytes == 4) ? &pivot_mid_4_0 : &pivot_mid_1_0;
  return pivot_functions[index][tag_bytes == 4];
}

pivot_f*
tensor_select_pivot_early(size_t tag_bytes, size_t item_bytes)
{
  int index = item_index(item_bytes);
  int logtag = _trailz(tag_bytes);
  if (_popcnt(tag_bytes) != 1 || logtag > 2)
    return NULL;
  if (index < 0)
    return ((pivot_f* [])
      { &pivot_early_1_0, &pivot_early_2_0, &pivot_early_4_0 }) [logtag];
  return pivot_functions[index][2 + logtag];
}

pivot_f*
tensor_select_pivot_late(size_t tag_bytes, size_t item_bytes)
{
  int index = item_index(item_bytes);
  int logtag = _trailz(tag_bytes);
  if (_popcnt(tag_bytes) != 1 || logtag > 2)
    return NULL;
  if (index < 0)
    return ((pivot_f* [])
      { &pivot_late_1_0, &pivot_late_2_0, &pivot_late_4_0 }) [logtag];
  return pivot_functions[index][5 + logtag];
}
