var searchData=
[
  ['link',['link',['../structconvey__codec.html#a610177d3708361783071ccca98e3508f',1,'convey_codec']]]
];
