var searchData=
[
  ['name',['name',['../structconvey__codec.html#a0e2ddb58935aa6c9f7d8acd67dc554e8',1,'convey_codec']]]
];
