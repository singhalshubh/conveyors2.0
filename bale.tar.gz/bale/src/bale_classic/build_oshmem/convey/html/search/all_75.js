var searchData=
[
  ['unlink',['unlink',['../structconvey__codec.html#aff0352a519f0bdbd44703eaf56cf400f',1,'convey_codec']]]
];
