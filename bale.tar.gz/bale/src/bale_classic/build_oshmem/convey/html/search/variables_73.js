var searchData=
[
  ['slack',['slack',['../structconvey__layout.html#a2f37df136d5ff59688220084a1d9f500',1,'convey_layout']]],
  ['stride',['stride',['../structconvey__layout.html#adc7ce05637e84e9760c5b1405db90c75',1,'convey_layout']]]
];
