var searchData=
[
  ['max_5fitems',['max_items',['../structconvey__cargo.html#accc2aeccc2eaba33d5fcc459e5c4d064',1,'convey_cargo']]]
];
