var searchData=
[
  ['packet_5fsize',['packet_size',['../structconvey__cargo.html#a32ed8ddb1e95dd493c2bdd0607971295',1,'convey_cargo']]],
  ['plan',['plan',['../structconvey__codec.html#a184c219af1bc41aaa44d8ee11c6f33e9',1,'convey_codec']]]
];
