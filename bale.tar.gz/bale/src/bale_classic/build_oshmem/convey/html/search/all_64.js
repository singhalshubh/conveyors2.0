var searchData=
[
  ['data',['data',['../structconvey__item__t.html#a936b4ab1ae619f209944da044595df62',1,'convey_item_t']]],
  ['decompress',['decompress',['../structconvey__codec.html#a5f61469d53582de804c7b2842473e6f2',1,'convey_codec']]],
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]]
];
