/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Preferred message size, or buffer capacity, in bytes */
#define CONVEY_BUFFER_SIZE 10000

/* Define to enable nonblocking puts */
#define ENABLE_NONBLOCKING 1

/* Define to activate mpp profiling and actimer. */
/* #undef ENABLE_PROFILING */

/* Define to 1 if you have the <actimer.h> header file. */
/* #undef HAVE_ACTIMER_H */

/* AVX2 instructions available */
/* #undef HAVE_AVX2 */

/* Define to 1 if you have the <bitops.h> header file. */
/* #undef HAVE_BITOPS_H */

/* BMI2 instructions available */
/* #undef HAVE_BMI2 */

/* Define to 1 if you have the `gethostname' function. */
#define HAVE_GETHOSTNAME 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the `actimer' library (-lactimer). */
/* #undef HAVE_LIBACTIMER */

/* Define to 1 if you have the `m' library (-lm). */
#define HAVE_LIBM 1

/* Define to 1 if you have the `mpp_utilV4' library (-lmpp_utilV4). */
/* #undef HAVE_LIBMPP_UTILV4 */

/* Define to 1 if you have the `mpp_utilV4_prof' library (-lmpp_utilV4_prof).
   */
/* #undef HAVE_LIBMPP_UTILV4_PROF */

/* Define to 1 if you have the `rt' library (-lrt). */
/* #undef HAVE_LIBRT */

/* Define to 1 if you have the `z' library (-lz). */
/* #undef HAVE_LIBZ */

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the <micro64.h> header file. */
/* #undef HAVE_MICRO64_H */

/* Define to 1 if you have the <mpi.h> header file. */
/* #undef HAVE_MPI_H */

/* Define if the build is based on mpp_utilV4. */
/* #undef HAVE_MPP_UTIL */

/* Define to 1 if you have the <mpp_utilV4.h> header file. */
/* #undef HAVE_MPP_UTILV4_H */

/* Define if getopt() understands optreset. */
/* #undef HAVE_OPTRESET */

/* Define if you have POSIX threads libraries and header files. */
/* #undef HAVE_PTHREAD */

/* Define if shmemx_alltoallv exists. */
/* #undef HAVE_SHMEMX_ALLTOALLV */

/* Define if shmemx_putmem_signal exists. */
/* #undef HAVE_SHMEMX_PUTMEM_SIGNAL */

/* Define if shmemx_team_alltoallv exists. */
/* #undef HAVE_SHMEMX_TEAM_ALLTOALLV */

/* Define if shmem_align exists. */
#define HAVE_SHMEM_ALIGN 1

/* Define if shmem_free exists. */
#define HAVE_SHMEM_FREE 1

/* Define if shmem_global_exit exists. */
#define HAVE_SHMEM_GLOBAL_EXIT 1

/* Define to 1 if you have the <shmem.h> header file. */
#define HAVE_SHMEM_H 1

/* Define if shmem_ptr exists and should be used. */
#define HAVE_SHMEM_PTR 1

/* Define if shmem_putmem_nbi exists. */
#define HAVE_SHMEM_PUTMEM_NBI 1

/* SSSE3 instructions available */
/* #undef HAVE_SSSE3 */

/* Define to 1 if you have the <stdalign.h> header file. */
#define HAVE_STDALIGN_H 1

/* Define to 1 if you have the <stdatomic.h> header file. */
#define HAVE_STDATOMIC_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if the system has the type `uintptr_t'. */
#define HAVE_UINTPTR_T 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define if upc_castable.h exists. */
/* #undef HAVE_UPC_CASTABLE_H */

/* Define to 1 if you have the <upc.h> header file. */
/* #undef HAVE_UPC_H */

/* Define to 1 if _Atomic long long and atomic_store() are usable. */
#define HAVE_USABLE_ATOMICS 1

/* Define to 1 if the system has the type `_Atomic uint64_t'. */
#define HAVE__ATOMIC_UINT64_T 1

/* Define if the build is based on raw MPI. */
/* #undef MPP_RAW_MPI */

/* Define if the build is based on raw SHMEM. */
#define MPP_RAW_SHMEM 1

/* Define if the build is based on UPC. */
/* #undef MPP_USE_UPC */

/* Define to 1 if your C compiler doesn't accept -c and -o together. */
/* #undef NO_MINUS_C_MINUS_O */

/* Name of package */
#define PACKAGE "convey"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "bale@super.org"

/* Define to the full name of this package. */
#define PACKAGE_NAME "convey"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "convey 0.6.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "convey"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.6.0"

/* Define to necessary symbol if this constant uses a non-standard name on
   your system. */
/* #undef PTHREAD_CREATE_JOINABLE */

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "0.6.0"

/* Define to the type of an unsigned integer type wide enough to hold a
   pointer, if such a type exists, and if the system does not define it. */
/* #undef uintptr_t */
