## Steps to run profiling

We profile push, pull, advance and total application time, to understand the bottlenecks on a coarse-level, function-wise.

#### Triangle Counting
```
srun -N 8 -n 192 ./triangle_conveyor -n 200000 &> debug.txt
srun -N 16 -n 384 ./triangle_conveyor -n 100000 &> debug.txt
srun -N 32 -n 768 ./triangle_conveyor -n 50000 &> debug.txt
srun -N 64 -n 1536 ./triangle_conveyor -n 25000 &> debug.txt

srun -N 8 -n 192 ./triangle_conveyor -n 800000 &> debug.txt
srun -N 16 -n 384 ./triangle_conveyor -n 400000 &> debug.txt
srun -N 32 -n 768 ./triangle_conveyor -n 200000 &> debug.txt
srun -N 64 -n 1536 ./triangle_conveyor -n 100000 &> debug.txt
```

#### TC AGL
```
srun -N 8 -n 192 ./tc -u 25 -k 100 -c &> debug.txt
srun -N 16 -n 384 ./tc -u 25 -k 100 -c &> debug.txt
srun -N 32 -n 768 ./tc -u 25 -k 100 -c &> debug.txt
srun -N 64 -n 1536 ./tc -u 25 -k 100 -c &> debug.txt

srun -N 8 -n 192 ./tc -u 27 -k 100 -c &> debug.txt
srun -N 16 -n 384 ./tc -u 27 -k 100 -c &> debug.txt
srun -N 32 -n 768 ./tc -u 27 -k 100 -c &> debug.txt
srun -N 64 -n 1536 ./tc -u 27 -k 100 -c &> debug.txt
```

#### Jaccard
```
srun -N 8 -n 192 ./jaccard -n 50000 &> debug.txt
srun -N 16 -n 384 ./jaccard -n 25000 &> debug.txt
srun -N 32 -n 768 ./jaccard -n 12500 &> debug.txt
srun -N 64 -n 1536 ./jaccard -n 6250 &> debug.txt

srun -N 8 -n 192 ./jaccard -n 100000 &> debug.txt
srun -N 16 -n 384 ./jaccard -n 50000 &> debug.txt
srun -N 32 -n 768 ./jaccard -n 25000 &> debug.txt
srun -N 64 -n 1536 ./jaccard -n 12500 &> debug.txt
```

#### Histogram
```
srun -N 8 -n 192 ./histo_conveyor -n 20000000 -T 20000000 &> debug.txt
srun -N 16 -n 384 ./histo_conveyor -n 10000000 -T 10000000 &> debug.txt
```

#### Index Gather
```
srun -N 8 -n 192 ./ig -n 20000000 -T 20000000 &> debug.txt
srun -N 16 -n 384 ./ig -n 10000000 -T 10000000 &> debug.txt
```