import matplotlib.pyplot as plt
import numpy as np

import statistics
import re

def extract_values_from_file(file_path, regex_pattern):
    """
    Extract numeric values from a file using a regex pattern.

    :param file_path: Path to the file.
    :param regex_pattern: Regular expression to search for values.
    :return: List of numeric values extracted from the file.
    """
    values = []
    with open(file_path, 'r') as file:
        for line in file:
            match = re.search(regex_pattern, line)
            if match:
                try:
                    values.append( ( int(match.group(1)), int(match.group(2)) ) )
                except ValueError:
                    pass
    return values

def calculate_stats(values):
    """
    Calculate the average and standard deviation of a list of values.

    :param values: List of numeric values.
    :return: Tuple of (average, standard deviation).
    """
    if not values:
        return None, None

    average = statistics.mean(values)
    std_dev = statistics.stdev(values) if len(values) > 1 else 0
    return average, std_dev/average

def main():
    """
    Main function to extract values and calculate statistics.
    """
    file_path = "debug.txt"

    regex_pattern = r"Async calls: \s*(\d+), pe: \s*(\d+)"  
    values = extract_values_from_file(file_path, regex_pattern)
    x, y = zip(*values)
    plt.figure(figsize=(8, 6))
    plt.plot(y, x, 'o') 
    plt.grid(True)
    plt.savefig('plot.png')

    
if __name__ == "__main__":
    main()
