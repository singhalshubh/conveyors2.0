import statistics
import re

def extract_values_from_file(file_path, regex_pattern):
    """
    Extract numeric values from a file using a regex pattern.

    :param file_path: Path to the file.
    :param regex_pattern: Regular expression to search for values.
    :return: List of numeric values extracted from the file.
    """
    values = []
    with open(file_path, 'r') as file:
        for line in file:
            match = re.search(regex_pattern, line)
            if match:
                try:
                    value = int(match.group(1))  # Changed to handle uint64_t
                    values.append(value)
                except ValueError:
                    pass
    return values

def calculate_stats(values):
    """
    Calculate the average and standard deviation of a list of values.

    :param values: List of numeric values.
    :return: Tuple of (average, standard deviation).
    """
    if not values:
        return None, None

    average = statistics.mean(values)
    std_dev = statistics.stdev(values) if len(values) > 1 else 0
    return average, std_dev/average

def main():
    """
    Main function to extract values and calculate statistics.
    """
    file_path = "debug.txt"  # Replace with your file path
    regex_pattern = r"Push-time: \s*(\d+) cycles"  
    values = extract_values_from_file(file_path, regex_pattern)

    average, std_dev = calculate_stats(values)
    print(f"[PUSH] - Average: {average}, Standard Deviation: {std_dev}")

    regex_pattern = r"Pull-time: \s*(\d+) cycles"  
    values = extract_values_from_file(file_path, regex_pattern)
    average, std_dev = calculate_stats(values)
    print(f"[PULL] - Average: {average}, Standard Deviation: {std_dev}")

    regex_pattern = r"Advance-time: \s*(\d+) cycles"  
    values = extract_values_from_file(file_path, regex_pattern)
    average, std_dev = calculate_stats(values)
    print(f"[ADVANCE] - Average: {average}, Standard Deviation: {std_dev}")

    regex_pattern = r"Total-time: \s*(\d+) cycles"  
    values = extract_values_from_file(file_path, regex_pattern)
    average, std_dev = calculate_stats(values)
    print(f"[TOTAL] - Average: {average}, Standard Deviation: {std_dev}")

    regex_pattern = r"Total-time reported by application: \s*(\d+)"  
    values = extract_values_from_file(file_path, regex_pattern)
    average, std_dev = calculate_stats(values)
    print(f"[APP] - Average: {average}, Standard Deviation: {std_dev}")

    regex_pattern = r"Pull-time reported by application: \s*(\d+)"  
    values = extract_values_from_file(file_path, regex_pattern)
    average, std_dev = calculate_stats(values)
    print(f"[APP pull] - Average: {average}, Standard Deviation: {std_dev}")

    regex_pattern = r"Porter 0, Network:\s*(\d+)"  
    values = extract_values_from_file(file_path, regex_pattern)
    average, std_dev = calculate_stats(values)
    print(f"[Network-Time, Porter 0] - Average: {average}, Standard Deviation: {std_dev}")

    regex_pattern = r"Porter 1, Network:\s*(\d+)"  
    values = extract_values_from_file(file_path, regex_pattern)
    average, std_dev = calculate_stats(values)
    print(f"[Network-Time, Porter 1] - Average: {average}, Standard Deviation: {std_dev}")

    regex_pattern = r"Porter 2, Network:\s*(\d+)"  
    values = extract_values_from_file(file_path, regex_pattern)
    average, std_dev = calculate_stats(values)
    print(f"[Network-Time, Porter 2] - Average: {average}, Standard Deviation: {std_dev}")

    regex_pattern = r"Inter-Porter Time \s*(\d+) cycles"  
    values = extract_values_from_file(file_path, regex_pattern)
    average, std_dev = calculate_stats(values)
    print(f"[Inter-Porter Time] - Average: {average}, Standard Deviation: {std_dev}")


if __name__ == "__main__":
    main()